function s=M8_2(x)
summ=sum(x.^2);
s=summ;
end