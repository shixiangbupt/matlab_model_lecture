function F=M6_3(x)
F=4*x(1)^2+4*x(2)^4;
