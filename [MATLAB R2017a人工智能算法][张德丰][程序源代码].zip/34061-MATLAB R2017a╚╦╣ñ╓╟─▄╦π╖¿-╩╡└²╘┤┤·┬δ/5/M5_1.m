 clear all;
x = 0:0.1:10;
y = pimf(x,[1 4 5 10]);
plot(x,y);
xlabel('pimf, P = [1 4 5 10]')
ylim([-0.05 1.05])
