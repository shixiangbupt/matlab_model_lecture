function s=M10_2a(x)
summ=sum(x.^2);
s=summ;
end