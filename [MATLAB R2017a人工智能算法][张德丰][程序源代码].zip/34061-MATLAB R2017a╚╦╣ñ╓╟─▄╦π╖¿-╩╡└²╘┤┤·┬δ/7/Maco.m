function F=Maco(x1,x2)
F=-(x1.^4+3*x2.^4-0.2*cos(3*pi*x1)-0.4*cos(4*pi*x2)+0.6);
