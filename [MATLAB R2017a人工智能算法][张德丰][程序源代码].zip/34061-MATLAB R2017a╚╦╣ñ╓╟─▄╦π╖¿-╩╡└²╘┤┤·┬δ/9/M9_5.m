function y=M9_6(x)
if x<=2 & x>=-1
    y=-(x*sin(10*pi*x)+2.0);
else
    y=0;
end