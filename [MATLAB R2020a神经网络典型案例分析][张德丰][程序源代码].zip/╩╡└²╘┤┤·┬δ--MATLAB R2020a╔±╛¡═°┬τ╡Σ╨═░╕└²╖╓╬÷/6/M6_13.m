 clear all;
z1 = [1, 2, 4; 3, 4, 1];
z2 = [-1, 2, 2; -5, -6, 1];
b = [0; -1]
n = netsum({z1, z2, concur(b, 3)})
