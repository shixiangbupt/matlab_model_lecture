clear all;
p=[0 1;-2 2];
t=1;
net=newp(p,t);
P=[0 0 1 1;0 1 0 1];
T=[0 1 1 1];
Y1=net(P)
net.trainParam.epochs=20;
net=train(net,P,T);
Y2=net(P)
