 clear all;
x=-5:.5:5;
y=x.^2-x-1;
net = newff(minmax(x),minmax(y),10);
net = train(net,x,y);
xx=-5:.25:5;
yy=net(xx);
plot(x,y,'rd-',xx,yy,'v-')
grid on;
