clear all;
x=-5:.1:5;
y=tansig(x);            %Tan-Sigmoid����
plot(x,y,'rv-');
xlabel('x');ylabel('y');
grid on
