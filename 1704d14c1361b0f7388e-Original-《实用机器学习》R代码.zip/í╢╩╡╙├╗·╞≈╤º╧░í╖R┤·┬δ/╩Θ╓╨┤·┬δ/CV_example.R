# CV_example.R
# In this script, we demonstrate a basic example of cross-validation
# In terms of model, we use logistic regression implemented in glmnet

# Remove all objects in the workspace
rm(list=ls())

# Step 0. Install and load the glmnet package
# Check if the package glmnet is installed. If not, install it first.
glmnet.installed <- 'glmnet' %in% rownames(installed.packages())
if (glmnet.installed) {
  print("the glmnet package is already installed, let's load it...")
}else {
  print("let's install the glmnet package first...")
  install.packages('glmnet', dependencies=T)
}
library(glmnet)

# Step 1. Load the data and set parameters
f_in <- 'Data/pima-indians-diabetes.csv'
D <- read.csv(f_in)
D$class <- as.factor(D$class)
y <- D$class
X <- D
X$class <- NULL
X <- as.matrix(X)
k <- 5

# Step 2. Split the data into k folds
n <- nrow(D)
# Set random seed to reproduce results
set.seed(0)
v_random <- sample(n)
v_fold <- rep(1, n)
sample_size_per_fold <- floor(n/k)
for (i in 1:k) {
  range_min = (i-1) * sample_size_per_fold + 1
  range_max = i * sample_size_per_fold
  v_fold[(v_random>=range_min) & (v_random<=range_max)] <- i
}

# Step 3. Perform cross-validation for several logistic regression models
lambda_list <- c(0, 0.001, 0.005, 0.01, 0.02, 0.03, 0.05, 0.1, 1)
param_num <- length(lambda_list)

# We use a matrix to score the prediction on the validation data set
Y_valid <- matrix(0, n, param_num)
for (i in 1:param_num) {
  lambda <- lambda_list[i]
  y_valid <- rep(0, n)
  for (j in 1:k) {
    X_train <- X[v_fold!=j, ]
    y_train <- y[v_fold!=j]
    X_valid <- X[v_fold==j,]
    # Train the model
    Mj <- glmnet(X_train, y_train, family = 'binomial', lambda = lambda)
    # Make prediction on the validation data set
    y_valid_j <- predict(Mj,  X_valid, type='class')
    y_valid[v_fold==j] <- y_valid_j
  }
  Y_valid[, i] <- y_valid
}

# Step 4. Pick the optimal lambda and rebuild the model using the whole training data set
accuracy_list <- rep(0, param_num)
for (i in 1:param_num) {
  accuracy_list[i] <- sum(Y_valid[,i]==y) / n
}
lambda_optimal <- lambda_list[which.max(accuracy_list)]
msg = paste0('lambda_optimal = ', lambda_optimal)
print(msg)
M_optimal <- glmnet(X, y, family = 'binomial', lambda = lambda_optimal)