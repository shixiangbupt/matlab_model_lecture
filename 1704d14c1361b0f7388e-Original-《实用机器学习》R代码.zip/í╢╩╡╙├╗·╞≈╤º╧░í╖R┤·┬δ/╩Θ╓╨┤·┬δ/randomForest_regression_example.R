# randomForest_regression_example.R
# In this script, we demonstrate how to use the randomForest package for a regression
# problem.
# Step 1. Load the data and simple exploration
# Step 2. Split the data into training and test sets
# Step 3. Benchmark: train a single decision tree using rpart
# Step 4. train 2 randome forest models using different parameters
# Step 5. Combine 3 random forest models together using the combine function
# Step 6. Continuously grow a random forest by training more trees, and
# plot the RMSE of training and test as the number of trees increases.
# Step 7. Check the importance of all variables

# Remove all objects in the workspace first
rm(list=ls())

# Check required package is installed or not. If not, install it.
randomForest.installed <- 'randomForest' %in% rownames(installed.packages())
if (randomForest.installed) {
  print("the randomForest package is already installed, let's load it...")
}else {
  print("let's install the randomForest package first...")
  install.packages('randomForest', dependencies=T)
}
library('randomForest')

#========================
# Step 1. Load the data and simple exploration
# load the mtcars data
data(mtcars)
D <- mtcars

# show the type for each col
for(i in 1:ncol(D)) {
  msg <- paste('col ', i, ' and its type is ', class(D[,i]))
  print(msg)
}

# Step 2. Split the data into training and test sets
# Randomly split the whole data set into a training and a test data set
# After spliting, we have the training set: (X_train, y_train)
# and the test data set: (X_test, y_test)
train_ratio <- 0.7
n_total <- nrow(D)
n_train <- round(train_ratio * n_total)
n_test <- n_total - n_train
set.seed(42)
list_train <- sample(n_total, n_train)
D_train <- D[list_train,]
D_test <- D[-list_train,]

y_train <- D_train$mpg
y_test <- D_test$mpg

# Step 3. Benchmark: train a single decision tree using rpart
library('rpart')
M_rpart1 <- rpart(mpg~., data = D_train)
print('show the summary of the trained model')
summary(M_rpart1)

# Compute the performance on the training and test data sets
y_test_pred_rpart1 <- predict(M_rpart1, D_test)
rmse_test_rpart1 <- sqrt(sum((y_test - y_test_pred_rpart1)^2) / n_test)
msg <- paste0('rmse_test_rpart1 = ', rmse_test_rpart1)
print(msg)

y_train_pred_rpart1 <- predict(M_rpart1, D_train)
rmse_train_rpart1 <- sqrt(sum((y_train - y_train_pred_rpart1)^2) / n_train)
msg <- paste0('rmse_train_rpart1 = ', rmse_train_rpart1)
print(msg)


# Step 4. train 2 randome forest models using different parameters
# Step 4.1 Train a random forest model using default parameters
# the default number of trees is 500
M_randomForest1 <- randomForest(mpg~., data = D_train)
print('show the summary of the trained model')
summary(M_randomForest1)
# We can get mean of squared residuals using the print function directlty
print(M_randomForest1)
# We can check the number of trees of the trained model
ntree1 <- M_randomForest1$ntree
msg <- paste0('number of trees in M_randomForest1 = ', ntree1)
print(msg)

# Get the prediction on the test set and compute the RMSE
y_test_pred_rf1 <- predict(M_randomForest1, D_test)
rmse_test_rf1 <- sqrt(sum((y_test - y_test_pred_rf1)^2) / n_test)
msg <- paste0('rmse_test_rf1 = ', rmse_test_rf1)
print(msg)

y_train_pred_rf1 <- predict(M_randomForest1, D_train)
rmse_train_rf1 <- sqrt(sum((y_train - y_train_pred_rf1)^2) / n_train)
msg <- paste0('rmse_train_rf1 = ', rmse_train_rf1)
print(msg)

# We train a second model using fewer decision trees, and control the 
# complexity of each tree.
M_randomForest2 <- randomForest(mpg~., data = D_train, ntree=50, mtry=3)
print('show the summary of the trained model')
summary(M_randomForest2)
print(M_randomForest2)
# We can check the number of trees of the trained model
ntree2 <- M_randomForest2$ntree
msg <- paste0('number of trees in M_randomForest2 = ', ntree2)
print(msg)


# Get the prediction on the test set and compute the RMSE
y_test_pred_rf2 <- predict(M_randomForest2, D_test)
rmse_test_rf2 <- sqrt(sum((y_test - y_test_pred_rf2)^2) / n_test)
msg <- paste0('rmse_test_rf2 = ', rmse_test_rf2)
print(msg)

y_train_pred_rf2 <- predict(M_randomForest2, D_train)
rmse_train_rf2 <- sqrt(sum((y_train - y_train_pred_rf2)^2) / n_train)
msg <- paste0('rmse_train_rf2 = ', rmse_train_rf2)
print(msg)


# Step 5. Combine 3 random forest models together using the combine function
# Train 3 random forest models
M_rf_base1 <- randomForest(mpg~., data = D_train, ntree = 15)
M_rf_base2 <- randomForest(mpg~., data = D_train, ntree = 20)
M_rf_base3 <- randomForest(mpg~., data = D_train, ntree = 10)
# Combine these 3 models just trained
M_rf_comb <- combine(M_rf_base1, M_rf_base2, M_rf_base3)
print(M_rf_comb)

# compute the performance on the test data set
y_test_pred_rf_base1 <- predict(M_rf_base1, D_test)
rmse_test_rf_base1 <- sqrt(sum((y_test - y_test_pred_rf_base1)^2) / n_test)
msg <- paste0('rmse_test_rf_base1 = ', rmse_test_rf_base1)
print(msg)

y_test_pred_rf_base2 <- predict(M_rf_base2, D_test)
rmse_test_rf_base2 <- sqrt(sum((y_test - y_test_pred_rf_base2)^2) / n_test)
msg <- paste0('rmse_test_rf_base2 = ', rmse_test_rf_base2)
print(msg)

y_test_pred_rf_base3 <- predict(M_rf_base3, D_test)
rmse_test_rf_base3 <- sqrt(sum((y_test - y_test_pred_rf_base3)^2) / n_test)
msg <- paste0('rmse_test_rf_base3 = ', rmse_test_rf_base3)
print(msg)

y_test_pred_rf_comb <- predict(M_rf_comb, D_test)
rmse_test_rf_comb <- sqrt(sum((y_test - y_test_pred_rf_comb)^2) / n_test)
msg <- paste0('rmse_test_rf_comb = ', rmse_test_rf_comb)
print(msg)


# Step 6. Continuously grow a random forest by training more trees, and
# plot the RMSE of training and test as the number of trees increases.

ntree_list <- 1:200
ntree_length <- length(ntree_list)
rmse_train_list <- rep(0, ntree_length)
rmse_test_list <- rep(0, ntree_length)
for (i in 1:ntree_length) {
  # Build the random forest model based on the existing random forest model
  if (i==1) {
    M_rf_base <- randomForest(mpg~., data = D_train, ntree = ntree_list[1])
  }else {
    ntree_delta <- ntree_list[i] - ntree_list[i-1]
    M_rf_base <- grow(M_rf_base, ntree_delta)
  }
  # Compute rmse on training and test data set
  y_train_pred_rfi <- predict(M_rf_base, D_train)
  y_test_pred_rfi <- predict(M_rf_base, D_test) 
  rmse_train_rfi <- sqrt(sum((y_train - y_train_pred_rfi)^2) / n_train)
  rmse_test_rfi <- sqrt(sum((y_test - y_test_pred_rfi)^2) / n_test)
  rmse_train_list[i] <- rmse_train_rfi
  rmse_test_list[i] <- rmse_test_rfi
}
# Plot the training and test RMSE
y_min <- min(min(rmse_test_list), min(rmse_train_list)) - 0.1
y_max <- max(max(rmse_test_list), max(rmse_train_list)) + 0.1
plot(range(ntree_list), c(y_min, y_max), type='n', xlab='ntree', ylab='RMSE')
lines(ntree_list, rmse_train_list, type='l', lty=1, col='black')
lines(ntree_list, rmse_test_list, type='l', lty=2, col='red')
legend_char_list <- c('training data', 'test data')
# We can use locator(1) to specify the legend position by clicking the mouse
#legend(locator(1), legend_char_list, cex=1.2, col=c('red', 'black'), lty=c(1,2))
# Or we can specify the legend position directly
legend("topright", legend_char_list, cex=1.2, col=c('black', 'red'), lty=c(1,2))

# Step 7. Check the importance of all variables
# We train a new random forest model consisting of 100 trees
M_rf_imp <- randomForest(mpg~., data = D_train, ntree = 100, importance = T)
print('we show the variable importance using OOB samples')
var_imp1 <- importance(M_rf_imp, type=1)
print(var_imp1)

print('we show the variable importance using tree node impurity/MSE descrease')
var_imp2 <- importance(M_rf_imp, type=2)
print(var_imp2)

# Plot the importance of all variables
varImpPlot(M_rf_imp, main = 'Variable importance of M_rf_imp')
