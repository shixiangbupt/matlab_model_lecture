# SVM_example1.R
# In this script, we demonstrate how train SVM using the e1071 package.

# Remove all objects in the workspace
rm(list=ls())

# Check required packages are installed or not. If not, install them.
e1071.installed <- 'e1071' %in% rownames(installed.packages())
if (e1071.installed) {
  print("the e1071 package is already installed, let's load it...")
}else {
  print("let's install the e1071 package first...")
  install.packages('e1071', dependencies=T)
}
library('e1071')

# Load the data
f_in <- 'Data/pima-indians-diabetes.csv'
D <- read.csv(f_in)
D$class <- as.factor(D$class)
# Show the type for each column
for(i in 1:ncol(D)) {
  msg <- paste('col ', i, ' and its type is ', class(D[,i]))
  print(msg)
}

# Explore the first 10 rows and the last 10 rows
D_h10 <- head(D, 10)
print('the first 10 rows are:')
print(D_h10)
D_t10 <- tail(D, 10)
print('the last 10 rows are:')
print(D_t10)

# Randomly split the whole data set into a training and a test data set
train_ratio <- 0.7
n_total <- nrow(D)
n_train <- round(train_ratio * n_total)
n_test <- n_total - n_train
list_train <- sample(n_total, n_train)
D_train <- D[list_train,]
D_test <- D[-list_train,]

# 
# y_test <- D_test$class
# y_train <- D_train$class
# X_train <- D_train
# X_train$class <- NULL
# #X_train <- as.matrix(X_train)
# X_test <- D_test
# X_test$class <- NULL
# #X_test <- as.matrix(X_test)


#=== Use case 1: a linear kernel with cost=1
svm.linear.model1 <- svm(class ~., data = D_train, kernel = 'linear', cost = 1)
svm.linear.pred1 <- predict(svm.linear.model1, D_test)
accuracy.linear1 <- sum(svm.linear.pred1==D_test$class) / n_test
msg <- paste('accuracy.linear1 = ', accuracy.linear1)
print(msg)
print('the summary of this model is')
print(summary(svm.linear.model1))


#=== Use case 2: a linear kernel with cost=100
svm.linear.model2 <- svm(class ~., data = D_train, kernel = 'linear', cost = 100)
svm.linear.pred2 <- predict(svm.linear.model2, D_test)
accuracy.linear2 <- sum(svm.linear.pred2==D_test$class) / n_test
msg <- paste('accuracy.linear2 = ', accuracy.linear2)
print(msg)
print('the summary of this model is')
print(summary(svm.linear.model2))


# Use case 3: a Radial kerenl with cost = 1, and gamma=1e-2
svm.radial.model1 <- svm(class ~., data = D_train, kernel = 'radial', cost = 1, gamma = 1e-2)
svm.radial.pred1 <- predict(svm.radial.model1, D_test)
accuracy.radial1 <- sum(svm.radial.pred1==D_test$class) / n_test
msg <- paste('accuracy.radial1 = ', accuracy.radial1)
print(msg)
print('the summary of this model is')
print(summary(svm.radial.model1))

# Use case 4: a Radial kernel with cost=100 and gamma=1e-2
svm.radial.model2 <- svm(class ~., data = D_train, kernel = 'radial', cost = 1, gamma = 1)
svm.radial.pred2 <- predict(svm.radial.model2, D_test)
accuracy.radial2 <- sum(svm.radial.pred2==D_test$class) / n_test
msg <- paste('accuracy.radial2 = ', accuracy.radial2)
print(msg)
print('the summary of this model is')
print(summary(svm.radial.model2))

# use case 5: a polynomial kernel with degree 2
svm.poly.model1 <- svm(class ~., data = D_train, kernel = 'polynomial', degree = 2, cost = 1)
svm.poly.pred1 <- predict(svm.poly.model1, D_test)
accuracy.poly1 <- sum(svm.poly.pred1==D_test$class) / n_test
msg <- paste('accuracy.poly1 = ', accuracy.poly1)
print(msg)
print('the summary of this model is')
print(summary(svm.poly.model1))

# Use case 6: a polynomial kernel with degree 3
svm.poly.model2 <- svm(class ~., data = D_train, kernel = 'polynomial', degree = 3, cost = 1)
svm.poly.pred2 <- predict(svm.poly.model2, D_test)
accuracy.poly2 <- sum(svm.poly.pred2==D_test$class) / n_test
msg <- paste('accuracy.poly2 = ', accuracy.poly2)
print(msg)
print('the summary of this model is')
print(summary(svm.poly.model2))


# Use grid search to find the optimal parameter for svm for the data set
# we consider a radical kernel and consider two parameters together: gamma and cost
tune.obj <- tune.svm(class~., data = D_train, 
                     gamma = c(1e-4, 1e-3, 1e-2), 
                     cost = c(1, 10))
print('summary of the cross-validation')
print(summary(tune.obj))
# Extract the optimal parameter value
gamma_best <- tune.obj$best.parameters$gamma
cost_best <- tune.obj$best.parameters$cost
