# regression_measures_examples.R
# This script demonstrates how to use functions in regression_measures.R

source('regression_measures.R')

# The testing cases are from scikit.learn
# y_true is the true target
# y_pred is our prediction
print('test R2')
y_true = c(3, -0.5, 2, 7)
y_pred = c(2.5, 0.0, 2, 8)

R2 = R2_score(y_true, y_pred) #0.948...

print('test RMSE')
rmse = RMSE(y_true, y_pred) #0.612372

print('test MAE')
mae = MAE(y_true, y_pred) # 0.5

print('test NRMSE')
nrmse = NRMSE(y_true, y_pred) # 0.08164966

print('test CVRMSE')
cvrmse = CVRMSE(y_true, y_pred) # 0.2129991