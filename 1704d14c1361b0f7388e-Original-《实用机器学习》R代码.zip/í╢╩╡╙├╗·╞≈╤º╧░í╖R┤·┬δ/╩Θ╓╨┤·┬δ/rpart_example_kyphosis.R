# rpart_example_kyphosis.R
# In this script, we demonstrate how to use the rpart package to train a decision tree
# on the kyphosis dataset. 
# We also show how to prune a tree and visualize the generated decision tree.

# Remove all objects in the workspace
rm(list=ls())

# Step 0. Check required packages are installed or not. If not, install them.
rpart.installed <- 'rpart' %in% rownames(installed.packages())
if (rpart.installed) {
  print("the rpart package is already installed, let's load it...")
}else {
  print("let's install the rpart package first...")
  install.packages('rpart', dependencies=T)
}
library('rpart')

# The partykit is also used to draw the decision tree
# partykit provides some very good graphing and visualization of tree models
partykit.installed <- 'partykit' %in% rownames(installed.packages())
if (partykit.installed) {
  print("the partykit package is already installed, let's load it...")
}else {
  print("let's install the partykit package first...")
  install.packages('partykit', dependencies=T)
}
library('partykit')

#========================
# Step 1. Load the data
# load the data
data(kyphosis)
D <- kyphosis
print('the basic information of D')
str(D)


# Step 2. Train decision tree models using rpart
# Step 2.1 Train a rpart model using default settings
M_rpart1 <- rpart(Kyphosis~., data = D, method = 'class')
print('show the trained model')
print(M_rpart1)
print('show the detailed summary of splits')
summary(M_rpart1)
print('plot the tree')
plot(as.party(M_rpart1), main='decision tree using default setting')

# Step 2.2 Check cp and the corresponding CV error
# 'cp' stands for Complexity Parameter of the tree.
# plot a complexity parameter table for an Rpart Fit 
plotcp(M_rpart1)
# display CP table for fitted Rpart object
C <- printcp(M_rpart1)

# Step 2.3. Prune the resulting decision using the optimal cp value and the prune function
cp_optimal <- C[which.min(C[,'xerror']), 'CP']
M_rpart1.1 <- prune(M_rpart1, cp = cp_optimal)
print(M_rpart1.1)
print('plot the pruned tree')
plot(as.party(M_rpart1.1), main='pruned decision tree')

# Step 2.4 Train a tree using more complicated parameter setting
M_rpart2 <- rpart(Kyphosis~., data = D, method = 'class',
                  control = rpart.control(minsplit = 10, minbucket = 5, maxdepth = 4))
print('show the summary of the trained model')
print(M_rpart2)
# plot the resulting tree
plot(as.party(M_rpart2), main='decision tree using advanced parameter setting')

# Step 3. Make prediction using the predict function, and compute accuracy
# We use the first 10 samples from D as the test data set
D_test <- D[1:10,]
# Output the probability first
y_test_prob <- predict(M_rpart1, D_test)
print(y_test_prob)
# Get the explicit class label next
y_test_label <- predict(M_rpart1, D_test, type='class')
print(y_test_label)
# Compute the corresponding accuracy
accuracy_test <- sum(D_test$Kyphosis==y_test_label) / length(y_test_label)
print(paste0('accuracy on the test data set is ', accuracy_test))