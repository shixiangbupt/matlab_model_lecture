# Auto_MPG_regression.R
# In this script, we show a full example to demonstrate how to perform regression in R 
# using the auto-mpg data set

# Remove all objects in the workspace
rm(list=ls())

# Load the data
f_in <- 'Data/regression_autoMPG.csv'
D <- read.csv(f_in)
rnorm_seed = 1

# Check if the package glmnet is installed. If not, install it first.
glmnet.installed <- 'glmnet' %in% rownames(installed.packages())
if (glmnet.installed) {
  print("the glmnet package is already installed, let's load it...")
}else {
  print("let's install the glmnet package first...")
  install.packages('glmnet', dependencies=T)
}
library('glmnet')


# Show the type for each col
for(i in 1:ncol(D)) {
  msg <- paste('col ', i, ' and its type is ', class(D[,i]))
  print(msg)
}
# Another way to briefly explore the data
str(D)

# Explore the first 10 rows and the last 10 rows
D_h10 <- head(D, 10)
print('the first 10 rows are:')
print(D_h10)
D_t10 <- tail(D, 10)
print('the last 10 rows are:')
print(D_t10)

# Preprocess categorical features
#Convert categorical variable to boolean variables
D$CountryCode1 <- ifelse(D$CountryCode==1, 1, 0)
D$CountryCode2 <- ifelse(D$CountryCode==2, 1, 0)
D$CountryCode <- NULL
D$Model <- NULL

# Randomly split the whole data set into a training and a test data set
train_ratio <- 0.7
n_total <- nrow(D)
n_train <- round(train_ratio * n_total)
#n_test <- n_total - n_train
list_sample <- sample(nrow(D))
list_train <- list_sample[1:n_train]
list_test <- list_sample[(n_train+1):n_total]
D_train <- D[list_train,]
D_test <- D[list_test,]
y_train <- D_train$MPG
y_test <- D_test$MPG


# Perform regression using lm
M1 <- lm(MPG~., data = D_train)
# Make prediction on the test data set
y_predict1 <- predict(M1, newdata=D_test)
# compute R2 and RMSE for this data set
# Load the functions to compute RMSE and R2
source('regression_measures.R')
R2_m1 <- R2_score(y_test, y_predict1)
rmse_m1 <- RMSE(y_test, y_predict1)

# plot the y_test and y_predict1
plot(y_test, y_predict1, type='p')
abline(c(0,1), col='red')
y_train_predict1 <- predict(M1, newdata=D_train)
y_train <- D_train$MPG
plot(y_train, y_train_predict1, type='p', main='prediction of M1 on training set')
abline(c(0,1), col='red')

# Train a ridge regression model using weight 0.25
# Note that the input data should be explicitly converted to matrix (not data frame)
family <- 'gaussian'
alpha <- 0
lambda <- 0.5
M2_1 <- glmnet(as.matrix(D_train[,2:ncol(D_train)]), 
               y_train, family = family, 
               lambda=lambda, alpha=alpha)
W2_1 <- M2_1$beta

# train a lasso using weight 1
family <- 'gaussian'
alpha <- 1
lambda <- 1
M1_1 <- glmnet(as.matrix(D_train[,2:ncol(D_train)]), 
               y_train, family = family, 
               lambda=lambda, alpha=alpha)
W1_1 <- M1_1$beta

# train an elastic net model with L1 weight equals 1 and L2 weight equals 3
family <- 'gaussian'
alpha <- 0.2
lambda <- 5
M_elastic <- glmnet(as.matrix(D_train[,2:ncol(D_train)]), 
                    y_train, family = family, 
                    lambda=lambda, alpha=alpha)
W_elastic <- M_elastic$beta

y_predict_elastic <- predict(M_elastic, 
                             newx=as.matrix(D_test[,2:ncol(D_test)]))



#==================================================
# use glmnet to perform ridge regression
# Here we test a sequence of lambda values
lambda_list <- seq(1, 0, by=-0.05)
lambda_num <- length(lambda_list)
X_train <- as.matrix(D_train[, 2:ncol(D_train)])
X_test <- as.matrix(D_test[, 2:ncol(D_test)])

RMSE_test_list_ridge <- rep(0, lambda_num)
family <- 'gaussian'
alpha <- 0
M_ridge_list <- glmnet(X_train, y_train, 
                       family = family, 
                       lambda=lambda_list, 
                       alpha=alpha)
y_predict_test_ridge <- predict(M_ridge_list, X_test)
#Compute the RMSE on the test data set
for (i in 1:lambda_num) {
  RMSE_test_list_ridge[i] <- RMSE(y_test, y_predict_test_ridge[,i])
}

# use glment to perform lasso
# Here we test the same sequence of lambda values
RMSE_test_list_lasso <- rep(0, lambda_num)
family <- 'gaussian'
alpha <- 1
M_lasso_list <- glmnet(X_train, y_train, 
                       family = family, 
                       lambda=lambda_list, 
                       alpha=alpha)
#Compute the RMSE on the test data set
y_predict_test_lasso <- predict(M_lasso_list, X_test)
for (i in 1:lambda_num) {
  RMSE_test_list_lasso[i] <- RMSE(y_test, y_predict_test_lasso[,i])
}

# Summarize RMSE of ridge regression and lasso
plot(c(min(lambda_list), max(lambda_list)), 
     range(c(RMSE_test_list_ridge, RMSE_test_list_lasso)), 
     type='n', xlab='lambda', ylab='RMSE')
lty = 'dashed'
lwd = 2
lines(lambda_list, RMSE_test_list_ridge, lwd=lwd, col='blue', lty=lty)
lty = 'solid'
lines(lambda_list, RMSE_test_list_lasso, lwd=lwd, col='red', lty=lty)

legend_char_list <- c('ridge regression', 'lasso')
legend('topleft', legend_char_list, cex=1.5, col=c('blue', 'red'), lty=c('dashed','solid'))



