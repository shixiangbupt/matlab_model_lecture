# caret_example.R
# In this example, we demonstrate how to use the caret package
# Here we use the Sonar data set, which is also provided in the 
# mlbench package. 

# Remove all objects in the workspace
rm(list=ls())

# Step 0. Check if the required packages are installed. We need to install
# the following packages before running the code
# 1. glmnet
# 2. rpart
# 3. caret
# 4. mlbench
glmnet.installed <- 'glmnet' %in% rownames(installed.packages())
if (glmnet.installed) {
  print("the glmnet package is already installed, let's load it...")
}else {
  print("let's install the glmnet package first...")
  install.packages('glmnet', dependencies=T)
}
library(glmnet)
rpart.installed <- 'rpart' %in% rownames(installed.packages())
if (rpart.installed) {
  print("the rpart package is already installed, let's load it...")
}else {
  print("let's install the rpart package first...")
  install.packages('rpart', dependencies=T)
}
library(rpart)
caret.installed <- 'caret' %in% rownames(installed.packages())
if (caret.installed) {
  print("the caret package is already installed, let's load it...")
}else {
  print("let's install the caret package first...")
  install.packages('caret', dependencies = c('Depends', 'Suggests'))
}
library(caret)
mlbench.installed <- 'mlbench' %in% rownames(installed.packages())
if (mlbench.installed) {
  print("the mlbench package is already installed, let's load it...")
}else {
  print("let's install the mlbench package first...")
  install.packages('mlbench', dependencies=T)
}
library(mlbench)

# Step 1. Load the Sonar data and do a brief check
data(Sonar)
str(Sonar)

# Step 2. Demonstrate different usages of caret to build logistic regression models

# 2.1 Train a logistic regression model using 5-fold cv (and run it 3 times)
# Notes: we need to convert input explicitly to matrix when we use glmnet directly
# But when we use caret to call glmnet, it will do it internally.
k = 5
cv_repeat_num <- 3
fitControl1 <- trainControl(method = 'repeatedcv',
                            number = k,
                            repeats = cv_repeat_num)
M_glmnet1 <- train(Class~., 
                   data = Sonar, 
                   method = 'glmnet', 
                   trControl = fitControl1)
# Check the optimal model parameter of the selected model via cross-validation
M_glmnet1$bestTune
# Check the model name, here it is glmnet
M_glmnet1$method
# Check the metric to be optimized, here it is Accuracy
M_glmnet1$metric
# Check the model type, here it is classification
M_glmnet1$modelType
# Check the performance (accuracy) for different parameter values
M_glmnet1$results

# 2.2 Train a logistic regression model using 5-fold cv and use provided parameter values
lambda_list <- c(0, 0.001, 0.005, 0.01, 0.02, 0.03, 0.05, 0.1, 1)
alpha_list <- c(0, 0.1)
myParamGrid <- expand.grid(lambda=lambda_list, alpha=alpha_list)
fitControl2 <- trainControl(method = 'repeatedcv',
                            number = k,
                            repeats = cv_repeat_num)
M_glmnet2 <- train(Class~., 
                   data = Sonar, 
                   method = 'glmnet', 
                   trControl = fitControl2, 
                   tuneGrid = myParamGrid)
# Check the optimal model parameter of the selected model via cross-validation
M_glmnet2$bestTune
# Check the performance (accuracy) for different parameter values
M_glmnet2$results

# 3 Train a logistic regression model using 5-fold cv to maximize AUC
fitControl3 <- trainControl(method = 'repeatedcv',
                            number = k,
                            repeats = cv_repeat_num,
                            classProbs = T,
                            summaryFunction = twoClassSummary)
M_glmnet3 <- train(Class~., 
                   data = Sonar, 
                   method = 'glmnet', 
                   trControl = fitControl3, 
                   metric='ROC')
# Check the optimal model parameter of the selected model via cross-validation
M_glmnet3$bestTune
# Check the model name
M_glmnet3$method
# Check the metric to be optimized
M_glmnet3$metric
# Check the performance (accuracy) for different parameter values
M_glmnet3$results

# 4. Train a logistic regression model using 5-fold CV and provided parameter 
# values to maximize AUC
fitControl4 <- trainControl(method = 'repeatedcv',
                            number = k,
                            repeats = cv_repeat_num,
                            classProbs = T,
                            summaryFunction = twoClassSummary)
M_glmnet4 <- train(Class~., 
                   data = Sonar, 
                   method = 'glmnet', 
                   trControl = fitControl4,
                   tuneGrid = myParamGrid,
                   metric='ROC')
# Check the optimal model parameter of the selected model via cross-validation
M_glmnet4$bestTune
# Check the model name
M_glmnet4$method
# Check the metric to be optimized
M_glmnet4$metric
# Check the performance (accuracy) for different parameter values
M_glmnet4$results


# 5. Train a logistic regression model using part of the data (denoted as training set)
# and make prediction on the test data set
trainingIndex <- createDataPartition(y=Sonar$Class, p=0.6, list=F)
D_train <- Sonar[trainingIndex,]
D_test <- Sonar[-trainingIndex,]
fitControl5 <- trainControl(method = 'repeatedcv',
                            number = k,
                            repeats = cv_repeat_num)
M_glmnet5 <- train(Class~., 
                   data = D_train, 
                   method = 'glmnet', 
                   trControl=fitControl5)
y_test <- predict(M_glmnet5, newdata = D_test)


# Step 3. Train a decision tree model using rpart and cross-validation

# Train a rpart model using default parameters provided by caret and cross-validation
fitControl_rpart1 <- trainControl(method = 'repeatedcv',
                                  number = k,
                                  repeats = cv_repeat_num)
M_rpart1 <- train(Class~., 
                  data = Sonar, 
                  method = 'rpart', 
                  trControl = fitControl_rpart1)
# Check the optimal model parameter of the selected model via cross-validation
M_rpart1$bestTune
# Check the model name
M_rpart1$method
# Check the metric to be optimized
M_rpart1$metric
# Check the performance (accuracy) for different parameter values
M_rpart1$results


# Train a rpart model using provided parameter values and cross-validation
fitControl_rpart2 <- trainControl(method = 'repeatedcv',
                                  number = k,
                                  repeats = cv_repeat_num)
cp_list <- c(0, 0.01, 0.1, 1)
myParamGrid_rpart <- expand.grid(cp=cp_list)
M_rpart2 <- train(Class~., 
                  data = Sonar, 
                  method = 'rpart', 
                  trControl = fitControl_rpart2,
                  tuneGrid = myParamGrid_rpart)
# Check the optimal model parameter of the selected model via cross-validation
M_rpart2$bestTune
# Check the model name
M_rpart2$method
# Check the metric to be optimized
M_rpart2$metric
# Check the performance (accuracy) for different parameter values
M_rpart2$results
