# recommenderlab_example.R
# In this script, we show some examples to demonstrate the basic usages of the 
# recommenderlab package.
# The script include:
# 0. Install the recommenderlab package
# 1. Load usage data
# 2. Explore usage data
# 3. Preprocess the data
# 4. Build several recommendation models, make predictions, and compute metrics
#    4.1 Popular model which assigns the most popular items to all users
#    4.2 Item-based recommendation
#    4.3 User-based recommendation
#    4.4 SVD based recommendation
# 5. Build a hybrid model which combines multiple models together
# 6. Compare multiple models together


# Remove all objects in the workspace
rm(list=ls())

# Step 0. Install the recommenderlab package if neccessary
# Load required library
rlab.installed <- 'recommenderlab' %in% rownames(installed.packages())
if (rlab.installed) {
  print("the recommenderlab package is already installed, let's load it...")
}else {
  print("let's install the recommenderlab package first...")
  install.packages('recommenderlab', dependencies=T)
}
library(recommenderlab) 


# Step 1. Load several datasets provided by the recommenderlab package
data(MovieLense)
MovieLense
# 943 x 1664 rating matrix of class 'realRatingMatrix' with 99392 ratings.
data(Jester5k)
Jester5k
# Load a binaryRatingMatrix example
data(MSWeb)
MSWeb

# Step 2. Explore the data
# We can use utilities functions to compute basic statistics

# Visualizing a sample of this
image(sample(MovieLense, 500), main = "Raw ratings")
image(MSWeb[1:500,], main='raw ratings')

# get the rating distribution
summary(getRatings(MovieLense))
# check the size of MovieLense directly
n_user_num_movie <- dim(MovieLense)[1]
n_item_num_movie <- dim(MovieLense)[2]
# Other functions we can use to explore rating matrix dimensions
user_list_movie <- dimnames(MovieLense)[1]
item_list_movie <- dimnames(MovieLense)[2]
# Get all ratings as a numeric vector
Movie_v <- getRatings(MovieLense)
hist(Movie_v, main='Histogram of ratings', xlab='Rating')
# Get all ratings as a sparse matrix
Movie_Msp <- getRatingMatrix(MovieLense)
# use the list of functions provided by the package
# we can print out the class information
str(Movie_v)
str(Movie_Msp)
# Next we compute some statistics
Movie_n_ratings <- nratings(MovieLense)
hist(rowCounts(MovieLense), breaks=50, xlab="Num of users", ylab="Num of movies rated")
# Explore the mean rating for each movie
hist(colMeans(MovieLense), breaks=50, xlab="Rating", ylab="Num of movies")
# other functions we can used to explore the rating matrix
# rowCounts, colCounts
# rowMeans, colMeans
# rowSums, colSums
# rowSds, colSds


# format conversion: we can also convert rating matrix to the following objects using as function :
# 1. list
# 2. data frame
# 3. matrix
# Here we consider the first 3 users in MovieLense
ML_3u_list <- as(MovieLense[1:3,], 'list')
str(ML_3u_list)
ML_3u_matrix <- as(MovieLense[1:3,], 'matrix')
str(ML_3u_matrix)
ML_3u_df <- as(MovieLense[1:3,], 'data.frame')
str(ML_3u_df)


# Step 3. Normalize all ratings
MovieLense_c <- normalize(MovieLense, method='center')
summary(getRatings(MovieLense_c))
hist(getRatings(MovieLense_c), breaks=50)
# We can check the rowSums of MovieLense_c, all of them are very close to 0.
ML_c_rowSums <- rowSums(MovieLense_c)

MovieLense_c_item <- normalize(MovieLense, method='center', row=F)
# We can also check the colSums of MovieLense_c_item, all of them are very close to 0.
ML_c_colSums <- colSums(MovieLense_c_item)

MovieLense_z <- normalize(MovieLense, method='Z-score')
summary(getRatings(MovieLense_z))
hist(getRatings(MovieLense_z), breaks=50)
# We can also check the rowSds (row standard deviation) for
# MovieLense_z, all of them are 1.
ML_z_rowSds <- rowSds(MovieLense_z)


# Step 4. Build recommendation models

# Show all available models for binary rating matrix
recommenderRegistry$get_entries(dataType = "binaryRatingMatrix")
# Show all available models for real rating matrix
recommenderRegistry$get_entries(dataType = "realRatingMatrix")


#========================= Models for realRatingMatrix ===================
# Before we build the recommendaiton models, we spilt data into 3 parts:
# 1. usage data for users in the training data set: ML_train
# 2. usage data for users in the test data set which is known 
#    in making prediction: ML_test_known
# 3. usage data for users in the test data set which is held 
#   out as ground truth: ML_test_unknown
ML_e <- evaluationScheme(MovieLense,
                         method='split',
                         train=0.9,
                         given = -10,
                         goodRating=5)
ML_train <- getData(ML_e, 'train')
ML_test_known <- getData(ML_e, 'known')
ML_test_unknown <- getData(ML_e, 'unknown')
topN <- 10

# realRatingMatrix Model 1: Build a trivial model using most popular items
M_RR_p <- Recommender(ML_train, 
                      method='POPULAR')
# Make item recommendations for users
ML_test_topN_p <- predict(M_RR_p, ML_test_known, 
                          n=topN, type='topNList')
# Explore the returned prediction for the first
ML_test_topN_p_list <- as(ML_test_topN_p, 'list')
# Show the returned topN prediction for the first user in the test set
ML_test_topN_p_list[1]
# Predict ratings
ML_test_rating_p <- predict(M_RR_p, ML_test_known,type='ratings')
# Show the predicted rating as a list
ML_test_rating_p_list <- as(ML_test_rating_p, 'list')

# Compute metrics for topN results
ML_metric_topN_p <- calcPredictionAccuracy(ML_test_topN_p,
                                           ML_test_unknown,
                                           given=-10,
                                           goodRating=5)
# compute metrics based on rating prediction
# metrics averaged over all recommendations
ML_metric_rating_p <- calcPredictionAccuracy(ML_test_rating_p,
                                             ML_test_unknown)
# metrics averaged by users: we compute metrics for each user
ML_metric_rating_by_user_p <- calcPredictionAccuracy(ML_test_rating_p,
                                                     ML_test_unknown,
                                                     byUser=T)

# realRatingMatrix Model 2: IBCF (Item-Based Collaborative Filtering)
M_RR_ibcf <- Recommender(ML_train,
                         method='IBCF',
                         param=list(k=20,
                                    normalize='center'))
# Make item recommendations for users
ML_test_topN_ibcf <- predict(M_RR_ibcf, ML_test_known,
                             n=topN, type='topNList')
# Explore the returned prediction for the first
ML_test_topN_ibcf_list <- as(ML_test_topN_ibcf, 'list')
# Show the returned topN prediction for the first user in the test set
ML_test_topN_ibcf_list[1]
# Predict ratings
ML_test_rating_ibcf <- predict(M_RR_ibcf, ML_test_known, type='ratings')
# Show the predicted rating as a list
ML_test_rating_ibcf_list <- as(ML_test_rating_ibcf, 'list')
# Compute metrics for topN results
ML_metric_topN_ibcf <- calcPredictionAccuracy(ML_test_topN_ibcf,
                                              ML_test_unknown,
                                              given=-10,
                                              goodRating=5)
# compute metrics based on rating prediction
# metrics averaged over all recommendations
ML_metric_rating_ibcf <- calcPredictionAccuracy(ML_test_rating_ibcf,
                                                ML_test_unknown)
# metrics averaged by users: we compute metrics for each user
ML_metric_rating_by_user_ibcf <- calcPredictionAccuracy(ML_test_rating_ibcf,
                                                        ML_test_unknown,
                                                        byUser=T)

# realRatingMatrix Model 3: UBCF (User-Based Collaborative Filtering)
M_RR_ubcf <- Recommender(ML_train,
                         method='UBCF',
                         param=list(method='cosine',
                                    nn=30,
                                    normalize='center'))
# Predict recommendation for users in the test data set
ML_test_topN_ubcf <- predict(M_RR_ubcf, ML_test_known,
                             n=topN, type='topNList')
ML_test_rating_ubcf <- predict(M_RR_ubcf, ML_test_known, type='ratings')
# Compute metrics
ML_metric_topN_ubcf <- calcPredictionAccuracy(ML_test_topN_ubcf,
                                              ML_test_unknown,
                                              given=-10,
                                              goodRating=5)
ML_metric_rating_ubcf <- calcPredictionAccuracy(ML_test_rating_ubcf,
                                                ML_test_unknown)

# We can choose different distance metrics in building the UBCF model.
# Available distance metrics include:
# "cosine", "pearson", or "jaccard"
M_RR_ubcf2 <- Recommender(ML_train,
                          method='UBCF',
                          param=list(method='pearson',
                                     nn=30,
                                     sample=F,
                                     normalize='center'))

# realRatingMatrix Model 4. SVD using stochastic gradient descent algorithm
print('we are going to train two SVD models, which may take several minutes')
M_RR_svd <- Recommender(ML_train,
                         method='SVD',
                         param=list(k=15,
                                    maxiter=500,
                                    normalize='center'))
M_RR_svdf <- Recommender(ML_train,
                        method='SVDF',
                        param=list(k=15,
                                   lambda=0.001,
                                   max_epochs=50,
                                   normalize='center'))
# Make item recommendations for users
ML_test_topN_svd <- predict(M_RR_svd, ML_test_known, 
                            n=topN, type='topNList')
# Predict ratings
ML_test_rating_svd <- predict(M_RR_svd, ML_test_known, type='ratings')
# Compute metrics
ML_metric_topN_svd <- calcPredictionAccuracy(ML_test_topN_svd,
                                              ML_test_unknown,
                                              given=-10,
                                              goodRating=5)
ML_metric_rating_svd <- calcPredictionAccuracy(ML_test_rating_svd,
                                                ML_test_unknown)

#========================= Models for binaryRatingMatrix ===================
# For the binaryRatingMatrix, we use MSWeb data set
# Also we split the data into 3 parts:
# 1. MSWeb_train; 2. MSWeb_test_known; 3. MSWeb_test_unknown.
MSW3 <- MSWeb[rowCounts(MSWeb)>3,]
MSW_e <- evaluationScheme(MSW3,
                          method='split',
                          train=0.9,
                          given=-3)
MSW_train <- getData(MSW_e, 'train')
MSW_test_known <- getData(MSW_e, 'known')
MSW_test_unknown <- getData(MSW_e, 'unknown')
topN <- 10

#========================= Models for binaryRatingMatrix ===================
# Note that matrix factorization model is not implemented for binaryRatingMatrix
# in the recommenderlab package.
# binaryRatingMatrix Model 1: Popular item
M_BR_p <- Recommender(MSW_train, 
                      method='POPULAR')
# Make item recommendations for users
MS_test_topN_p <- predict(M_BR_p, MSW_test_known, 
                          n=topN, type='topNList')
# Explore the returned prediction for the first
MSW_test_topN_p_list <- as(MS_test_topN_p, 'list')
# Show the returned topN prediction for the first user in the test set
MSW_test_topN_p_list[1]
# For popular model, we cannot predict ratings for binaryRatingMatrix
# Compute metrics for the topN recommendations


# binaryRatingMatrix Model 2: IBCF (Item-Based Collaborative Filtering)
M_BR_ibcf <- Recommender(MSW_train,
                         method='IBCF',
                         param=list(k=20,
                                    method='Jaccard',
                                    normalize_sim_matrix=F))
# Make item recommendations for users
MSW_test_topN_ibcf <- predict(M_BR_ibcf, MSW_test_known, 
                              n=topN, type='topNList')
# Explore the returned prediction for the first
MSW_test_ibcf_list <- as(MSW_test_topN_ibcf, 'list')
# Show the returned topN prediction for the first user in the test set
MSW_test_ibcf_list[1]


# binaryRatingMatrix Model 3: UBCF (User-Based Collaborative Filtering)
M_BR_ubcf <- Recommender(MSW_train,
                         method='ubcf',
                         param=list(method='Jaccard',
                                    nn = 20,
                                    weighted=T))
# Make item recommendations for users
MSW_test_topN_ubcf <- predict(M_BR_ubcf, MSW_test_known, 
                              n=topN, type='topNList')
# Compute the corresponding metrics
MSW_metric_topN_ubcf <- calcPredictionAccuracy(MSW_test_topN_ubcf,
                                               MSW_test_unknown,
                                               given=3)

# Step 5. Build a hybrid model for MovieLense 
# In the first example, we mix 3 different models
M_RR_h1 <- HybridRecommender(M_RR_ibcf,
                             M_RR_ubcf,
                             M_RR_svd,
                             weights=c(0.3, 0.2, 0.5))
ML_test_topN_h1 <- predict(M_RR_h1, ML_test_known,
                           n=topN, type='topNList')
ML_test_rating_h1 <- predict(M_RR_h1, ML_test_known,type='ratings')



# Step 6. Use the evaluation framework provided by recommenderlab to evaluate built 
# recommendation models
# We first generate the splitting for the Jester5k data
# And then compare different algorithms.
J_e <- evaluationScheme(Jester5k[1:1000], 
                        method="split", 
                        train = .9,
                        k=1, 
                        given=-5, 
                        goodRating=5)
algorithms2compare <- list(
  "random items" = list(name="RANDOM", param=NULL),
  "popular items" = list(name="POPULAR", param=NULL),
  "user-based CF" = list(name="UBCF", param=list(nn=50)),
  "item-based CF" = list(name="IBCF", param=list(k=50)),
  "SVD approximation" = list(name="SVD", param=list(k = 50))
)

J_results_topN <- evaluate(J_e, algorithms2compare, 
                           type = "topNList",
                           n=c(1, 3, 5, 10, 15, 20))
J_results_topN
names(J_results_topN)
J_results_topN[["user-based CF"]]
plot(J_results_topN, annotate=c(1,2,4), legend="bottomright")
plot(J_results_topN, "prec/rec", annotate=4, legend="topleft")

# Compare ratings
J_results_rating <- evaluate(J_e, algorithms2compare, type = "ratings")
J_results_rating
plot(J_results_rating)
