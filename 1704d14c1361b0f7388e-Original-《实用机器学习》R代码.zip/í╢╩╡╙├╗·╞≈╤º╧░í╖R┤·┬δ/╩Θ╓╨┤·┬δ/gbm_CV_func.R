# gbm_CV_func.R
# This script contains the general framework using gbm and caret packages to 
# perform cross-validation.

# Important parameters to be tuned in gbm package and caret package:
# 1. n.trees, number of trees
# 2. interaction.depth, the interation depth for input features
# 3. shrinkage: the shrinkage rate in learning process



# Step 0. Check if the gbm package has been installed. If not, install it first
# Check required packages are installed or not. If not, install them.
# 1. gbm
gbm.installed <- 'gbm' %in% rownames(installed.packages())
if (gbm.installed) {
  print("the gbm package is already installed, let's load it...")
}else {
  print("let's install the gbm package first...")
  install.packages('gbm', dependencies=T)
}
library('gbm')
# 2. caret
caret.installed <- 'caret' %in% rownames(installed.packages())
if (caret.installed) {
  print("the caret package is already installed, let's load it...")
}else {
  print("let's install the caret package first...")
  install.packages('caret', dependencies = c('Depends', 'Suggests'))
}
library('caret')
source('classification_measures.R')


# This function is the core part.
# It uses caret and gbm packages to perform cross validation
# It follows the unified input/output interfaces.
# Basically, this function reads the data and controlling parameters,
# and then return the
gbm_CV_func <- function(x, y, training_ratio = 0.75, 
                       cv_fold = 5, 
                       repeat_num = 10, 
                       customMetric = 'Accuracy', 
                       customGrid = NULL,
                       trainingIndex = NULL) {
  if (!is.factor(y)) {
    y <- as.factor(y)
  }
  if (length(levels(y))==2) {
    isBinary <- T
  }else {
    isBinary <- F
  }
  
  # Perform CV in caret
  # Partition the data set into training/test data set
  if (is.null(trainingIndex)) {    
    set.seed(998)
    inTraining <- createDataPartition(y, p = training_ratio, list = FALSE)
    x.train <- x[inTraining, ]
    y.train <- y[inTraining]
    x.test <- x[-inTraining, ]
    y.test <- y[-inTraining]
  }else {
    x.train <- x[trainingIndex, ]
    y.train <- y[trainingIndex]
    x.test <- x[-trainingIndex, ]
    y.test <- y[-trainingIndex]
  }
  
  
  # train the model
  # set different control settings for binary and multi classification. 
  if (isBinary) {    
    if (toupper(customMetric)=='AUC') {
      fitControl <- trainControl(method = "repeatedcv",  
                                 number = cv_fold,
                                 repeats = repeat_num,
                                 classProbs = T,
                                 summaryFunction = twoClassSummary)      
      customMetric <- 'ROC'
    }else if (toupper(customMetric)=='F1') {
      fitControl <- trainControl(method = "repeatedcv",  
                                 number = cv_fold,
                                 repeats = repeat_num,
                                 summaryFunction = binaryClassMetric)
    }else {
      # the default is accuracy
      fitControl <- trainControl(method = "repeatedcv",  
                                 number = cv_fold,
                                 repeats = repeat_num)
    }   
    
  }else {
    fitControl <- trainControl(method = "repeatedcv",
                               summaryFunction = multiClassMetric,
                               number = cv_fold,
                               repeats = repeat_num)
  }
    
  set.seed(825)
  myModel <- train(x.train, y.train, 
                   method = 'gbm',
                   trControl = fitControl,
                   tuneGrid = customGrid,
                   metric = customMetric,
                   verbose = FALSE)

  # make prediction and calculate the performance metrics
  y.test.hat <- predict(myModel, newdata = x.test)
  y.test.prob.M <- predict(myModel, newdata = x.test, type = "prob")
  
  if (!isBinary) {
    # this is multi-class classifcation
    ConfM <- confusion_multi(y.test, y.test.hat, levels(y.test)) 
    M <- ConfM$confusionMatrix
    maF1 <- macroF1(M)
    miF1 <- microF1(M)
    accu <- accuracyConf(M)    
    auc <- 0
  }else {
    # this is binary-class classfication
    # compute the confusion matrix first
    is_class2 <- y.test==levels(y)[2]
    pred_class2 <- y.test.hat==levels(y)[2]
    ConfM <- confusion_binary(is_class2, pred_class2)
    M <- ConfM$confusionMatrix
    F1 <- F1_binary(M)
    maF1 <- F1
    miF1 <- F1
    accu <- sum(y.test.hat==y.test) / length(y.test)
    # compute AUC if neccessary
    if (exists("y.test.prob.M")) {
      auc <- AUC(y.test==levels(y)[1], y.test.prob.M[[1]])
    }else {
      auc <- 0
    }
  }
  
  
  # Summarize the returning results
  R <- {}
  R$Accuracy <- accu
  R$AUC <- auc
  R$MicroF1 <- miF1
  R$MacroF1 <- maF1
  
  # Store the best parameters selected in cross-validation
  R$bestTune <- myModel$bestTune
  
  R$model <- myModel
  R$y.test.hat <- y.test.hat
  
  return(R)
}