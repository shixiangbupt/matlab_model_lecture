# rpart_example_tree_plot.R
# In this script, we demonstrate how to visualize the resulting
# decision tree using different packages. 


# Remove all objects in the workspace
rm(list=ls())

# Step 0. Check required packages are installed or not. If not, install them.
rpart.installed <- 'rpart' %in% rownames(installed.packages())
if (rpart.installed) {
  print("the rpart package is already installed, let's load it...")
}else {
  print("let's install the rpart package first...")
  install.packages('rpart', dependencies=T)
}
library('rpart')
# The partykit is used to draw the decision tree
# partykit provides some very good graphing and visualization of tree models
partykit.installed <- 'partykit' %in% rownames(installed.packages())
if (partykit.installed) {
  print("the partykit package is already installed, let's load it...")
}else {
  print("let's install the partykit package first...")
  install.packages('partykit', dependencies=T)
}
library('partykit')
# Install the rattle package for more fancy tree plotting
# The rattle package depends on tens of packages, so it will take a while
# to download and install them. Please be patient.
rattle.installed <- 'rattle' %in% rownames(installed.packages())
if (rattle.installed) {
  print("the rattle package is already installed, let's load it...")
}else {
  print("let's install the rattle package first...")
  install.packages('rattle', dependencies=T)
}
library('rattle')


#========================
# Step 1. Load the kyphosis data
# load the data
data(kyphosis)
D <- kyphosis
print('the summary of D is')
print(str(D))

# Step 2. Train a decision tree using rpart
# Train a rpart model using default settings
M_rpart1 <- rpart(Kyphosis~., data = D)
print('show the summary of the trained model')
summary(M_rpart1)

# Step 3. Plot the resulting decision tree using different packages.
# Plot1. Use function plot.rpart and text.rpart provided by the rpart package
plot(M_rpart1)
text(M_rpart1)

# Plot1.1 More complicated setting
plot(M_rpart1, uniform=TRUE, main="Classifcation Tree in rpart", cex=0.5)
text(M_rpart1, use.n=TRUE, all=TRUE, cex=0.8)

# Plot2. Use the plot.party function provided by partykit package
plot(as.party(M_rpart1), main="Decision Tree in partykit")

# Plot3. Use the rpart.plot function provided by rpart.plot package
rpart.plot(M_rpart1, main='Decision Tree in rpart.plot')

# Plot4. Use the fancyRpartPlot provided by rattle package
fancyRpartPlot(M_rpart1, main='Decision Tree in rattle')






