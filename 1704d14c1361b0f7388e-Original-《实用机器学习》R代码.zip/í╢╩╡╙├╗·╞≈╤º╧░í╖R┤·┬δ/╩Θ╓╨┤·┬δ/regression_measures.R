# regression_measures.R
# In this script, we compute the performance metrics in regression, including:
# 1. Root-Mean-Square-Error (RMSE)
# 2. Normalized RMSE (NRMSE), i.e., RMSE normalized by the range of the ground truth
# 3. Coefficient of Variance of RMSE (CV-RMSE), i.e., RMSE normalized by the mean of the ground truth
# 4. Mean Absolute Error (MAE)
# 5. Coefficient of Determination (R-Squared)
# All these functions provided in this script are self-explained.

# # This function computes the RMSE for regression
# y_true: the true label, a vector with length n
# y_predict: the predicted label, a vector with length n
# If an error happends, return -1
RMSE<-function(y_true, y_predict) {
  if (length(y_true)!=length(y_predict)) {
    return(-1)
  }
  
  yd = y_true - y_predict
  R = sum(yd*yd) / length(yd)
  R = sqrt(R)
  return(R)  
}


# # This function computes the normalized RMSE for regression
# y_true: the true label, a vector with length n
# y_predict: the predicted label, a vector with length n
# If an error happends, return -1
NRMSE<-function(y_true, y_predict) {
  rg = max(y_true) - min(y_true)
  nr = RMSE(y_true, y_predict)
  if (nr!=-1 && rg!=0) {
    nr = nr / rg
  }else {
    nr = -1
  }
  return(nr)
}

# # This function computes the Coefficient of Variance of RMSE for regression
# y_true: the true label, a vector with length n
# y_predict: the predicted label, a vector with length n
# If an error happends, return -1
CVRMSE<-function(y_true, y_predict) {
  m_true = mean(y_true)  
  nr = RMSE(y_true, y_predict)
  if (nr!=-1 && m_true!=0) {
    nr = nr / m_true
  }else {
    nr = -1
  }
  return(nr)
}


# # This function computes the Mean Absolute Error (MAE) for regression
# y_true: the true label, a vector with length n
# y_predict: the predicted label, a vector with length n
# If an error happends, return -1
MAE<-function(y_true, y_predict) {
  if (length(y_true)!=length(y_predict)) {
    return(-1)
  }
  
  yd = y_true - y_predict
  R = sum(abs(yd)) / length(y_true)
  return(R)  
}


# # This function computes the R-Squared for regression
# y_true: the true label, a vector with length n
# y_predict: the predicted label, a vector with length n
# If an error happends, return -1
R2_score<-function(y_true, y_predict) {
  if (length(y_true)!=length(y_predict)) {
    return(-1)
  }
  
  m_true = mean(y_true)
  ym_true = y_true - m_true
  SS_tot = sum(ym_true * ym_true)
    
  yd = y_true - y_predict
  SS_res = sum(yd*yd)
  
  R = 1 - SS_res/SS_tot
  return(R)
}
