# R_data_load_example.R
# In this script, we demonstrate how to load data from a local file or a URL
# Also we show how to compute basic statistics from the imported data.

# Clean all existing data in the workspace first
rm(list=ls())

# Step 1. We load data from a local file.
data_file = 'Data/iris.data'
D = read.csv(data_file, header=F)
# Get key statistics for this data frame
# show some samples of the data frame D
print('the first 10 rows of D is')
print(head(D, 10))
print('the last 10 rows of D')
print(tail(D, 10))
# Show the summary
print('summary of D')
print(summary(D))
# Check the type of the 1st column
c1 = class(D[,1])
msg = paste0('the type of 1st column is ', c1)
print(msg)
c5 = class(D[,5])
msg = paste0('the type of the 5th column is ', c5)
print(msg)

# An alternative function to load data
D1 = read.table(data_file, header=F, sep=',')
print('summary of D1')
print(summary(D1))

# Step 2. Load data from a URL directly
# We need to install RCurl package first. 
# Before we install it, we need to check if the RCurl package is already installed.
RCurl.installed <- 'RCurl' %in% rownames(installed.packages())
if (RCurl.installed) {
  print("the RCurl package is already installed, let's load it...")
}else {
  print("let's install the RCurl package first...")
  install.packages('RCurl', dependencies=T)
}
library('RCurl')
# Use RCurl to read the file specified by the URL f_URL
f_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
# f_text is the string we download for this URL
f_text = getURL(f_URL)
D2 = read.csv(text=f_text, header=F)
print('summary of D2')
print(summary(D2))

# Step 3. Load dataset provided by R
# list all data sets avaiable in R
data()
# load the mtcars dataset
data('mtcars')
print('summary of mtcars')
print(summary(mtcars))

# Step 4. Instead of using the summary function, we compute these statistics
# using separate functions
m1 = min(D[,1])
msg = paste0('min = ', m1)
print(msg)
m3 = max(D[,1])
msg = paste0('max = ', m3)
print(msg)
m2 = mean(D[,1])
msg = paste0('mean = ', m2)
print(msg)
md = median(D[,1])
msg = paste0('median = ', md)
print(msg)
q1 = quantile(D[,1], 0.25)
msg = paste0('25% quantile = ', q1)
print(msg)
q2 = quantile(D[,1], 0.5)
msg = paste0('50% quantile = ', q2)
print(msg)
q3 = quantile(D[,1], 0.75)
msg = paste0('75% quantile = ', q3)
print(msg)
# Check the skewness of a single column in R
# We need to install moments package first. 
# Before we install it, we need to check if the moments package is already installed.
moments.installed <- 'moments' %in% rownames(installed.packages())
if (moments.installed) {
  print("the moments package is already installed, let's load it...")
}else {
  print("let's install the moments package first...")
  install.packages('moments', dependencies=T)
}
library('moments')
s1 = skewness((D[,1]))
msg = paste0('the skewness of 1st column is ', s1)
print(s1)

print('the distribution of the 5th column')
t5 = table(D[,5])
print(t5)
