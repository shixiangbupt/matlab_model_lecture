# caret_custom_example.R
# In this example, we demonstrate how to optimize different classification
# performance metric and tuning of more parameters using caret package
# by customizing it.
# In this example, we use the function gbm_CV_func in gbm_CV_func.R to 
# demonstrate how to do it.

# Remove all objects in the workspace
rm(list=ls())

source('gbm_CV_func.R')

# Step 1. Load the data
# Here we load the Sonar data from mlbench package
# So we need to make sure mlbench is installed. 
mlbench.installed <- 'mlbench' %in% rownames(installed.packages())
if (mlbench.installed) {
  print("the mlbench package is already installed, let's load it...")
}else {
  print("let's install the mlbench package first...")
  install.packages('mlbench', dependencies=T)
}
library(mlbench)
data(Sonar)
D <- Sonar
# Split the data into training and test
training_ratio <- 0.7
n_total <- nrow(D)
n_training <- round(n_total * training_ratio)
trainingIndex <- sample(n_total, n_training)
# Make trainingIndex consistent with caret package
trainingIndex <- as.matrix(trainingIndex)
colnames(trainingIndex) <- 'Resample1'
# Prepare X and y
y <- D[, ncol(D)]
X <- D
X[, ncol(D)] <- NULL

# Step 2. Several examples
# For all examples below, we use the following parameters:
cv_fold <- 5
repeat_num <- 1

# Maximize F1 using customized grids with more tuning parameters
measure_standard <- 'F1'
gbm.n.trees_list <- 200
gbm.interaction.depth_list <- c(1, 2, 3)
gbm.shrinkage_list <- c(0.1, 0.01)
gbm.n.minobsinnode_list <- c(10, 5)
gbm.grid <- expand.grid(n.trees = gbm.n.trees_list, 
                        interaction.depth = gbm.interaction.depth_list,
                        shrinkage = gbm.shrinkage_list,
                        n.minobsinnode = gbm.n.minobsinnode_list)
R_gbm1 <- gbm_CV_func(X, y, cv_fold = cv_fold, 
                     customMetric = measure_standard, 
                     customGrid = gbm.grid,
                     trainingIndex = trainingIndex)

# Maximize AUC using customized grids with more tuning parameters
measure_standard <- 'AUC'
R_gbm2 <- gbm_CV_func(X, y, cv_fold = cv_fold, 
                      customMetric = measure_standard, 
                      customGrid = gbm.grid,
                      trainingIndex = trainingIndex)

# Maximize Accuracy using customized grids with more tuning parameters
measure_standard <- 'Accuracy'
R_gbm3 <- gbm_CV_func(X, y, cv_fold = cv_fold, 
                      customMetric = measure_standard, 
                      customGrid = gbm.grid,
                      trainingIndex = trainingIndex)