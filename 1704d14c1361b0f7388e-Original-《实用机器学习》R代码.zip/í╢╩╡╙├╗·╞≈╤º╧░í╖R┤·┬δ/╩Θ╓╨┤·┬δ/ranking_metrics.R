# ranking_metrics.R
# In this script, we compute differnet metrics in ranking, including
# 1. DCG
# 2. NDCG

# rel is the ground truth of the relevance score from the top to bottom.
DCG <- function(rel, max.rank) {
  # Step 1. Paramter checking
  if (missing(max.rank)) {
    max.rank <- length(rel)
  }
  if (max.rank>length(rel)) {
    max.rank <- length(rel)
  }
  
  # Step 2. Compute DCG
  rel <- rel[1:max.rank]
  position_weight <- 1/log2(2:(max.rank+1))
  #position_weight <- c(1, 1/log2(2:max.rank))
  v = sum(rel * position_weight)
  return(v)
}


NDCG <- function(rel, max.rank) {
  # Step 1. Paramter checking
  if (missing(max.rank)) {
    max.rank <- length(rel)
  }
  if (max.rank>length(rel)) {
    max.rank <- length(rel)
  }
  
  # Step 2. Compute DCG for the current ranking and the ideal ranking
  v <- DCG(rel, max.rank)
  rel_ideal <- sort(rel, decreasing = TRUE)
  V_ideal <- DCG(rel_ideal, max.rank)
  
  return(v/V_ideal)
}


# An example of binary relevance
# rel is ground truth of the relevance score of the list from the top to bottom.
rel = c(0,1,1,0,0,0,0,1)
DCG(rel)

rel_ideal = c(1,1,1,0,0,0,0,0)
DCG(rel_ideal)

# An exmple of ordinal relevance
rel <- c(3,2,3,0,1,2)
DCG(rel)
DCG(rel, 6)
DCG(rel, 5)

NDCG(rel, max.rank=6)
NDCG(rel)
NDCG(rel, 5)

