# utility_funcs.R

# This function converts categorical features to dummy variables
# for training set transform call categorical2binary(train_set)
# for test set transform call categorical2binary(train_set, test_set)
categorical2binary <- function(D_train, D_test=NULL) {
  if (is.null(D_test)) {
    # only D_train is considered
    for(i in 1:ncol(D_train)) {
      # We consider each columns in sequence
      if (is.factor(D_train[,i])) {
        # consider all levels, except the reference level
        colName <- colnames(D_train)[i]
        allLevels <- unique(D_train[,i])
        levelNum <- length(allLevels)
        for(j in 1:(levelNum-1)) {
          level <- allLevels[j]
          newColName <- paste(colName, level, sep='_')
          D_train[newColName] <- ifelse(D_train[,i]==level, 1, 0)
        }
        # Remove the original column
        D_train[colName] <- NULL
      }
    }
    return(D_train)
  }else {
    if (ncol(D_train)!=ncol(D_test)) {
      return(NULL)
    }
    
    for(i in 1:ncol(D_train)) {
      # process each columns of D_test and D_train in sequence
      if (is.factor(D_train[,i])) {
        # We only consider all levels in D_train
        # If a value in D_test does not contained in D_train, ignore it and set it as 'unknown_level'
        colName <- colnames(D_train)[i]
        allLevelsTrain <- unique(D_train[,i])
        allLevelsTest <- unique(D_test[,i])
        allLevelsDiff <- setdiff(allLevelsTest, allLevelsTrain)
        # Consider all levels excpet hte reference level in the training set first
        levelNumTrain <- length(allLevelsTrain)
        for(j in 1:(levelNumTrain-1)) {
          level <- allLevelsTrain[j]
          levelInTest <- allLevelsTest[allLevelsTest==as.character(level)]
          newColName <- paste(colName, level, sep='_')
          D_test[newColName] <- ifelse(D_test[,i]==levelInTest, 1, 0)
        }
        # If additional new levels appear in test set, handle them properly
        if (length(allLevelsDiff)>0) {
          newColName <- paste(colName, 'unknown_level', sep='_')
          D_test[newColName] <- 0
          for (level in allLevelsDiff) {
            D_test[D_test[,i]==level, newColName] <- 1
          }
        }
      }
    }
    return(D_test)
  }
}

# # Some examples
# # Please uncomment them before running these test cases.
# df1 <- data.frame(eggs=c('foo', 'foo', 'bar', 'bar'), ham=1:4)
# df2 <- data.frame(eggs=c('foo', 'bar', 'foo'), ham=5:7)
# df3 <- categorical2binary(df1)
# df4 <- categorical2binary(df1, df2)
# df2.1 <- data.frame(eggs=c('foo', 'bar', 'doo'), ham=5:7)
# df4.1 <- categorical2binary(df1, df2.1)
