# R_data_visualization.R
# In this script, we demonstrate how to draw the following charts/plots using functions
# provided in base R
# 1. hist
# 2. bar chart
# 3. stem-and-leaf plot
# 4. box plot
# 5. Scatter plot
# Data we are using in this script:
# 1. mtcars
# 2. iris
# We prepare a different script which uses the ggplot2 package to plot all these charts/plots.

rm(list=ls())

# Step 1. Load the data
data("iris")
data("mtcars")
# in the following we have two data frames: iris and mtcars

# Step 2. Plot the histogram using mtcars$mpg
# Plot a basic histogram
hist(mtcars$mpg)
# Plot a histogram with 10 bins
# Specify approximate number of bins with breaks
hist(mtcars$mpg, breaks=10)
# Plot a red histogram with 12 bins
hist(mtcars$mpg, breaks=12, col="red")
# Add labels
hist(mtcars$mpg, breaks=12, col="red", xlab = "Miles Per Gallon", main = "Histogram of mpg")

# Step 3. Plot a bar chart using iris$Species and mtcars$cyl
table_Species = table(iris$Species)
barplot(table_Species)
# plot a horizontal barplot
barplot(table_Species, horiz=T)

table_Species2 = table(iris[1:120, "Species"])
barplot(table_Species2, col='blue')


table_cyl = table(mtcars$cyl)
barplot(table_cyl)

table_gear = table(mtcars$gear)
barplot(table_gear)

plot(mtcars[,c('cyl', 'gear')])



# Step 4. Stem-and-leaf plot
sort(mtcars$disp)
stem(mtcars$disp)

# Step 5. Box plot
# Plot a basic boxplot using only 1 variable
boxplot(mtcars$mpg)
boxplot(mtcars$mpg, horizontal=T)
# Plot a basic boxplot for cars whose cyl=4
boxplot(mtcars[mtcars$cyl==4, 'mpg'])
# Plot a box plot invovling 2 variables.
boxplot(mpg~cyl,data=mtcars, main="Car Milage Data", 
        xlab="Number of Cylinders", ylab="Miles Per Gallon")
# Plot box plot involving 3 variables
boxplot(mpg~cyl*gear, data=mtcars, 
        col=(c("blue","red")),
        main="Car Milage Data", xlab="Cylinder and Gear")


# Step 6. Scatter plot
# Plot a basic scatter plot
plot(mtcars$wt, mtcars$mpg)
# We add more controls
plot(mtcars$wt, mtcars$mpg, main="Scatterplot Example", 
     xlab="Car Weight ", ylab="Miles Per Gallon ", pch=19)
# Advanced scatter plot using the car package
# The scatterplot( ) function in the car package offers many enhanced features, 
# including fit lines, marginal box plots, conditioning on a factor, 
# and interactive point identification. Each of these features is optional.
car.installed <- 'car' %in% rownames(installed.packages())
if (car.installed) {
  print("the car package is already installed, let's load it...")
  library('car')
}else {
  print("let's install the car package first...")
  install.packages('car', dependencies=T)
  library('car')
}
# Enhanced Scatterplot of MPG vs. Weight 
scatterplot(mpg ~  wt, data=mtcars, smoother=F,
            xlab="Weight of Car", ylab="Miles Per Gallon", 
            main="Enhanced Scatter Plot",
            labels=row.names(mtcars))
