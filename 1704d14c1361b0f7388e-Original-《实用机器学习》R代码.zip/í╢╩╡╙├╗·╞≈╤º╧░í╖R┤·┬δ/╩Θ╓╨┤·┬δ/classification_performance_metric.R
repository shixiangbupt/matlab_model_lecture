# classification_performance_metric.R
# In this script, we compute the classification performance metrics for classification problems
# A toy classification problem is investigated in this script.

rm(list=ls())

# Part 1. Generate the simulated data
prob_list = c(0.1, 0.3, 0.4, 0.5, 0.55, 0.7, 0.8, 0.85)
pred_list = ifelse(prob_list>=0.5, 1, -1)
label_list = c(-1, 1, -1, 1, 1, -1, 1, 1)
# In R, we use factor to store the label list
pred_list <- as.factor(pred_list)
label_list <- as.factor(label_list)


# Part 1. Compute accuracy
accuracy = sum(pred_list==label_list) / length(label_list)
msg = paste0('accuracy = ', accuracy)
print(msg)

# Part 2. Compute the confusion matrix, sensitivity, and specificity
# Here we use the confusionMatrix function in the caret package. 
# So here we first install caret package if it is not installed.
package_name <- 'caret'
package.installed <- package_name %in% rownames(installed.packages())
if (package.installed) {
  msg <- paste0("the ", package_name, " package is already installed, let's load it...")
  print(msg)
}else {
  msg <- paste0("let's install the ", package_name, "package first...")
  install.packages(package_name, dependencies=T)  
}
library('caret')
# We call the confusionMatrix in the caret package to compute the confusion matrix
# and other classification performance metrics.
confM1 <- confusionMatrix(data=pred_list, reference=label_list, positive='1')
print('the confusion matrix and other metrics are')
print(confM1)

# We can call the functions sensitivity and specificity in the caret package to
# compute them directly
sens <- sensitivity(data=pred_list, reference=label_list, positive='1')
spec <- specificity(data=pred_list, reference=label_list, negative='-1')
msg <- paste0('sensitivity = ', sens, ' and specificity = ', spec)
print(msg)


# Part 3. Plot ROC and compute AUC using the pROC package
package_name <- 'pROC'
package.installed <- package_name %in% rownames(installed.packages())
if (package.installed) {
  msg <- paste0("the ", package_name, " package is already installed, let's load it...")
  print(msg)
}else {
  msg <- paste0("let's install the ", package_name, "package first...")
  install.packages(package_name, dependencies=T)  
}
library('pROC')
# create an roc object using the roc function in pROC
rocCurve <- roc(response=label_list,
                predictor=prob_list)
# compute the AUC using the auc function
auc_value = auc(rocCurve)
print(auc_value)
# plot the ROC curve 
plot(rocCurve, legacy.axes=T)
