# R_example_Ch2.R
# In this script, we basically show some basics of R (as discussed in Chapter 2)

# Remove all objects in the workspace
rm(list=ls())

# Assignments and basic operations
x <- 3
4 -> y
z = 3.4

x0 <- x+z
x1 <- y-z
x2 <- x*y
x3 <- x/y
x4 <- x^y
x5 = x%%y
x6 = x%/%y
x7 = ++x

# String example
s1 = 'hello world'
s2 = "hello world"
s1==s2

# Control expression
n = 10
for(i in 1:n){
  if (i%%2)
    k = 1
  else
    k = 0
  cat("k=", k)
  cat("\n")
}

n = 10
s = 0
while(n>0){
  s <- s + n
  n <- n-1
  if(n==3)
    break
}

# paste function and paste0 function
paste('hello', 'world', sep='-')
paste('hello', 'world', 'from', 'R', sep='-')
paste(c("x","y","z"),1:7,sep="-")
paste(c("x","y","z"),1:7,sep="")
paste0(c("x", "y", "z"),1:7)

# cat function
k <- 10
cat("k=",k)
cat("\n")

# c function
x <- c(1, 0, 2, 9)
x1 <- c(1,0,2,9)
x2 <- c(4,3)
x3 <- c(x1, x2)


# Function examples
func1 <- function() {
  print('hello world')
}
func1()

aml_sum <- function(a, b) {
  r <- a+b
  return (r)
}
x<-3
y<-4
z<-aml_sum(x,y)
print(z)

# Type examples:
w <- c(TRUE, FALSE, TRUE)
x = 1:9
assign("y", c(2.5, 4.2, 1.8))
z <- c("m1","a2","c3","h4","i5","n6","e7")
class(w)
class(x)
class(y)
class(z)

# rep example
v_ch <- rep('', 5)
v_num <- rep(0, 5)
v_logic <- rep(FALSE, 5)

v_ch <- character(5)
v_num <- numeric(5)
v_logic <- logical(5)

# NA example
w <- NA
is.na(w)

# for loop and vector operations
u <- 1:5
v <- 6:10
w <- rep(0, length(u))
for (i in 1:length(u)) w[i] = u[i] + v[i]
w2 = u + v
w2 - w

x <- c(16, 33, 45, 88)
y <- x/2
print(y)
large <- x>17
x <- c(36, 16, 49, 81)
sqrt(sort(x, TRUE))



# Factor example
gender_v <- c('Male', 'Female', 'Female', 'Male')
f_gender <- factor(gender_v)
levels(f_gender)
f_gender_num <- as.numeric(f_gender)
# convert factor to character
f_gender_ch <- as.character(f_gender)


# Matrix example
x <- c(1, 2, 3, 4, 5, 6, 7, 8)
dim(x) <- c(2,4)
print(x)

array(1:8, dim=c(2,4))
matrix(1:8, nrow=2, byrow=FALSE)
array(1:27, dim=c(3,3,3))

M <- matrix(0, nrow=4, ncol=3)
M <- matrix(0, 4, 3)
colnames(M)
rownames(M)
colnames(M) <- c('F1', 'F2', 'F3')
colnames(M)

x <- array(c(1, 2, 3, 4, 5, 6, 7, 8), c(2,4))
y <- array(c(1, 2, 3, 4, 5, 6, 7, 8), c(4,2))
z <- x %*% y
print(z)

x <- matrix(rnorm(9), 3, 3)
y0 <- c(1, 0, 2)
z <- x %*% y0
y <- solve(x, z)
y <- solve(x) %*% z

# Data frame example
D <- read.csv('Data/Test-Chapter2.csv')
print(D)

Year <- 2010:2016
Volume <- c(3000,3500,4000,4500,5000,5500,6000)
Number <- c(307, 350, 480, 550, 700, 800, 1000)
df2 <- data.frame(Year, Volume, Number)
print(df2)

No. <- c(4001:4005)
Score <- c(82,77,90,63,85)
Age <- c(20, 19, 21, 22, 20)
df3 <- data.frame(No., Score, Age)
No. <- c(4006:4007)
Score <- c(92,65)
Age<- c(20, 19)
df4 <- data.frame(Score, Age, No.)

rbind(df3,df4)

Grade <- c('B','C','A','D','B')
df5 <- data.frame(Grade)
cbind(df3,df5)


# expand.grid example
age_v <- 6:8
gender_v <- c('Male', 'Female')
D <- expand.grid(age=age_v, gender=gender_v)

#list example
x <- list(1:4, 'b', c('ca', 'cb', 'cc'), c(FALSE, TRUE, TRUE), c(1.9, -1.7))
y <- list(c1=1:4, c2=c('ca', 'cb', 'cc'), c3=c(FALSE, TRUE, TRUE))
x1 <- x[1]
is.list(x1)
x2 <- x[1:2]
is.list(x2)
x3 <- x[[1]]
is.list(x3)

x[[2]] <- c('b', 'c')
x[[3]][1] <- 'ca_new'

names(x)
names(x) <- c('c_int', 'c_ch1', 'c_ch2', 'c_logical', 'c_numeric')
names(x)

x$c_int
x[["c_int"]]
x$c_i
x[c('c_int', 'c_numeric')]

name_list <- c('C_int', 'c_numeric')
for (n in name_list) 
  x[[n]] <- 2 * x[[n]]  

y <- list(c1=1:4, c2=c('ca', 'cb', 'cc'), c3=c(FALSE, TRUE, TRUE))
y[[4]] <- c(4,1)
y[['c_num']] <- c(1.9, -1.7)
names(y)

L1 <- list(c1=c(1,4), c2=c('aa', 'dd'))
L2 <- list(c3=c(TRUE, FALSE), c4=c(4.3, 1.5))
LC <- c(L1, L2)


# Indexing example
x <- 1:10
x[c(1,3)] <- 0
x[-c(1,3)] <- 1
x[x<5] <- 0

x <- 1:10
x[x%%2==0]=0

data(iris)
head(iris)


# Formula example
# formula1 <- as.formula(y~x1+x2+x3)
# class(formula1)
data(mtcars)
formula_demo <- as.formula(mpg ~ cyl + disp + hp + gear)
class(formula_demo)
M_lm <- lm(formula_demo, mtcars)
class(M_lm)
print(M_lm)
summary(M_lm)

# check packages
search()


glmnet.installed <- 'glmnet' %in% rownames(installed.packages())
if (glmnet.installed) {
  print("the glmnet package is already installed, let's load it...")
}else {
  print("let's install the glmnet package first...")
  install.packages('glmnet', dependencies=T)
}
library('glmnet')


# help
library(help = utils)
