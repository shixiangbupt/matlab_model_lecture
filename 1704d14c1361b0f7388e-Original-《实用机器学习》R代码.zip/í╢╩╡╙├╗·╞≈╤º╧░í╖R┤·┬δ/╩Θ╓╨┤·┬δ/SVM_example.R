# SVM_example1.R
# In this script, we demonstrate how train SVM using the e1071 package.

# Remove all objects in the workspace
rm(list=ls())

# Check required packages are installed or not. If not, install them.
e1071.installed <- 'e1071' %in% rownames(installed.packages())
if (e1071.installed) {
  print("the e1071 package is already installed, let's load it...")
}else {
  print("let's install the e1071 package first...")
  install.packages('e1071', dependencies=T)
}
library('e1071')

# Load the data
f_in <- 'Data/pima-indians-diabetes.csv'
D <- read.csv(f_in)
D$class <- as.factor(D$class)
# Show the type for each column
for(i in 1:ncol(D)) {
  msg <- paste('col ', i, ' and its type is ', class(D[,i]))
  print(msg)
}

# Explore the first 10 rows and the last 10 rows
D_h10 <- head(D, 10)
print('the first 10 rows are:')
print(D_h10)
D_t10 <- tail(D, 10)
print('the last 10 rows are:')
print(D_t10)

# Randomly split the whole data set into a training and a test data set
train_ratio <- 0.7
n_total <- nrow(D)
n_train <- round(train_ratio * n_total)
n_test <- n_total - n_train
list_train <- sample(n_total, n_train)
D_train <- D[list_train,]
D_test <- D[-list_train,]

# 
# y_test <- D_test$class
# y_train <- D_train$class
# X_train <- D_train
# X_train$class <- NULL
# #X_train <- as.matrix(X_train)
# X_test <- D_test
# X_test$class <- NULL
# #X_test <- as.matrix(X_test)


#=== Use case 1: a linear kernel with cost=1
svm.linear.model1 <- svm(class ~., data = D_train, kernel = 'linear', cost = 1)
svm.linear.pred1 <- predict(svm.linear.model1, D_test)
accuracy.linear1 <- sum(svm.linear.pred1==D_test$class) / n_test
msg <- paste('accuracy.linear1 = ', accuracy.linear1)
print(msg)
print('the summary of this model is')
print(summary(svm.linear.model1))


#=== Use case 2: a linear kernel with cost=100
svm.linear.model2 <- svm(class ~., data = D_train, kernel = 'linear', cost = 100)
svm.linear.pred2 <- predict(svm.linear.model2, D_test)
accuracy.linear2 <- sum(svm.linear.pred2==D_test$class) / n_test
msg <- paste('accuracy.linear2 = ', accuracy.linear2)
print(msg)
print('the summary of this model is')
print(summary(svm.linear.model2))


# Use case 3: a Radial kerenl with cost = 1, and gamma=1e-2
svm.radial.model1 <- svm(class ~., data = D_train, kernel = 'radial', cost = 1, gamma = 1e-2)
svm.radial.pred1 <- predict(svm.radial.model1, D_test)
accuracy.radial1 <- sum(svm.radial.pred1==D_test$class) / n_test
msg <- paste('accuracy.radial1 = ', accuracy.radial1)
print(msg)
print('the summary of this model is')
print(summary(svm.radial.model1))

# Use case 4: a Radial kernel with cost=100 and gamma=1e-2
svm.radial.model2 <- svm(class ~., data = D_train, kernel = 'radial', cost = 1, gamma = 1)
svm.radial.pred2 <- predict(svm.radial.model2, D_test)
accuracy.radial2 <- sum(svm.radial.pred2==D_test$class) / n_test
msg <- paste('accuracy.radial2 = ', accuracy.radial2)
print(msg)
print('the summary of this model is')
print(summary(svm.radial.model2))

# use case 5: a polynomial kernel with degree 2
svm.poly.model1 <- svm(class ~., data = D_train, kernel = 'polynomial', degree = 2, cost = 1)
svm.poly.pred1 <- predict(svm.poly.model1, D_test)
accuracy.poly1 <- sum(svm.poly.pred1==D_test$class) / n_test
msg <- paste('accuracy.poly1 = ', accuracy.poly1)
print(msg)
print('the summary of this model is')
print(summary(svm.poly.model1))

# Use case 6: a polynomial kernel with degree 3
svm.poly.model2 <- svm(class ~., data = D_train, kernel = 'polynomial', degree = 3, cost = 1)
svm.poly.pred2 <- predict(svm.poly.model2, D_test)
accuracy.poly2 <- sum(svm.poly.pred2==D_test$class) / n_test
msg <- paste('accuracy.poly2 = ', accuracy.poly2)
print(msg)
print('the summary of this model is')
print(summary(svm.poly.model2))

# Use case 7: test different cost values for the linear kernel
cost_list <- c(0.1, 1, 10, 100)
cost_num <- length(cost_list)
accuracy_train_list <- rep(0, cost_num)
accuracy_test_list <- rep(0, cost_num)
for(i in 1:cost_num) {
  cost_i <- cost_list[i]
  svm.linear.modeli <- svm(class ~., data = D_train, kernel = 'linear', cost = cost_i)
  
  pred.train.i <- predict(svm.linear.modeli, D_train)
  pred.test.i <- predict(svm.linear.modeli, D_test)
  accuracy_train_list[i] <- sum(pred.train.i==D_train$class) / n_train
  accuracy_test_list[i] <- sum(pred.test.i==D_test$class) / n_test
}
# plot the figure, which shows that this data set is not sensitive to the cost value
xlab <- 'Index of cost'
ylab <- 'Accuracy'
range2 <- range(c(accuracy_train_list, accuracy_test_list))
range2[2] <- range2[2] + 0.02
#plot(range(cost_list), range2 , type='n', xlab=xlab, ylab=ylab)
plot(range(1:cost_num), range2 , type='n', xlab=xlab, ylab=ylab)
lty <- 'dashed'
lwd <- 2
lines(1:cost_num, accuracy_train_list, lwd=lwd, col='blue', lty=lty)
lty <- 'solid'
lines(1:cost_num, accuracy_test_list, lwd=lwd, col='red', lty=lty)
legend_char_list <- c('training', 'test')
# legend(locator(1), legend_char_list, cex=1, col=c('blue', 'red'), lty=c('dashed','solid'))
legend('topleft', legend_char_list, cex=1, col=c('blue', 'red'), lty=c('dashed','solid'))


# Use case 8: test different gamma values for radial kernel
gamma_list <- c(1e-4, 5e-4, 1e-3, 5e-3, 1e-2, 1e-1, 10)
gamma_num <- length(gamma_list)
accuracy_train_list2 <- rep(0, gamma_num)
accuracy_test_list2 <- rep(0, gamma_num)
for(i in 1:gamma_num) {
  gamma_i <- gamma_list[i]
  svm.radial.modeli <- svm(class ~., data = D_train, kernel = 'radial', cost = 1, gamma = gamma_i)  
  
  pred.train.i <- predict(svm.radial.modeli, D_train)
  pred.test.i <- predict(svm.radial.modeli, D_test)
  accuracy_train_list2[i] <- sum(pred.train.i==D_train$class) / n_train
  accuracy_test_list2[i] <- sum(pred.test.i==D_test$class) / n_test
}
# plot the figure, which shows that this data set is not sensitive to the gamma value
xlab <- 'Index of gamma'
ylab <- 'Accuracy'
range2 <- range(c(accuracy_train_list2, accuracy_test_list2))
range2[2] <- range2[2] + 0.02
#plot(range(log(gamma_list+1)), range2 , type='n', xlab=xlab, ylab=ylab)
plot(range(1:gamma_num), range2 , type='n', xlab=xlab, ylab=ylab)
lty <- 'dashed'
lwd <- 2
lines(1:gamma_num, accuracy_train_list2, lwd=lwd, col='blue', lty=lty)
lty <- 'solid'
lines(1:gamma_num, accuracy_test_list2, lwd=lwd, col='red', lty=lty)
legend_char_list2 <- c('training', 'test')
# legend(locator(1), legend_char_list2, cex=1, col=c('blue', 'red'), lty=c('dashed','solid'))
legend('topleft', legend_char_list2, cex=1, col=c('blue', 'red'), lty=c('dashed','solid'))


# Use grid search to find the optimal parameter for svm for the data set
# we consider a radical kernel and consider two parameters together: gamma and cost
tune.obj <- tune.svm(class~., data = D_train, 
                     gamma = c(1e-4, 1e-3, 1e-2), 
                     cost = c(1, 10))
print('summary of the cross-validation')
print(summary(tune.obj))
# Extract the optimal parameter value
gamma_best <- tune.obj$best.parameters$gamma
cost_best <- tune.obj$best.parameters$cost
