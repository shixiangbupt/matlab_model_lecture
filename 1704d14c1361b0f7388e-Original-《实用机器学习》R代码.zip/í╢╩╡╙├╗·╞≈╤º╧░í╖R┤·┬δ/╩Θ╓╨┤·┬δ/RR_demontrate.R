# RR_demonstrate.R
# In this script we give a simple example of ridge regression
set.seed(10)
n = 1000
x1 = rnorm(1000)
x2 = rnorm(1000)
x3 = 0.6*x1 + 0.4*x2
x_matrix = cbind(x1, x2, x3)
x_cov = t(x_matrix)%*%x_matrix
delta = 0.6 * x_cov[,1] + 0.4 * x_cov[,2] - x_cov[,3]
delta