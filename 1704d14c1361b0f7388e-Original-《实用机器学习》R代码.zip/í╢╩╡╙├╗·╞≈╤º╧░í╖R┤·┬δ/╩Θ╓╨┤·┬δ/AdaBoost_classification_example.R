# AdaBoost_classification_example.R
# In this script, we demonstrate how to use AdaBoost in R for classification

# Remove all objects in the workspace
rm(list=ls())

# Step 0. Check required package is installed or not. If not, install first.
# 1. adabag
adabag.installed <- 'adabag' %in% rownames(installed.packages())
if (adabag.installed) {
  print("the adabag package is already installed, let's load it...")
}else {
  print("let's install the adabag package first...")
  install.packages('adabag', dependencies=T)
}
library('adabag')
library('rpart')

# Step 1. Load the Sonar data in the mlbench library
data(Sonar)
D <- Sonar
colnames(D)[ncol(D)] <- 'classLabel'

# Step 2. Split the data into training and test sets
# Randomly split the whole data set into a training and a test data set
# After spliting, we have the training set: (X_train, y_train)
# and the test data set: (X_test, y_test)
train_ratio <- 0.7
n_total <- nrow(D)
n_train <- round(train_ratio * n_total)
n_test <- n_total - n_train
set.seed(42)
list_train <- sample(n_total, n_train)
D_train <- D[list_train,]
D_test <- D[-list_train,]
y_train <- D_train$classLabel
y_test <- D_test$classLabel

# Step 3. Benchmark: train a single decision tree using rpart

M_rpart1 <- rpart(classLabel~., data = D_train)
print('show the summary of the trained model')
summary(M_rpart1)

# Compute the performance on the training and test data sets
y_test_pred_rpart1 <- predict(M_rpart1, D_test, type='class')
accuracy_test_rpart1 <- sum(y_test==y_test_pred_rpart1) / n_test
msg <- paste0('accuracy_test_rpart1 = ', accuracy_test_rpart1)
print(msg)

y_train_pred_rpart1 <- predict(M_rpart1, D_train, type='class')
accuracy_train_rpart1 <- sum(y_train==y_train_pred_rpart1) / n_train
msg <- paste0('accuracy_train_rpart1 = ', accuracy_train_rpart1)
print(msg)

# Step 4. Train a simple AdaBoost model
maxdepth <- 4
mfinal <- 60
M_AdaBoost1 <- boosting(classLabel~., data = D_train, 
                        boos = FALSE, mfinal = mfinal, coeflearn = 'Breiman',
                        control=rpart.control(maxdepth=maxdepth))

# Check the summary of the trained AdaBoost model
summary(M_AdaBoost1)
# We get all trees
M_AdaBoost1$trees
# print the 1st tree
M_AdaBoost1$trees[[1]]
# We get the weights for all trees
M_AdaBoost1$weights
# We get the variable importance
M_AdaBoost1$importance
# We get the evolution of the error
errorevol(M_AdaBoost1, D_train)
# Check the first tree trained in AdaBoost
t1 <- M_AdaBoost1$trees[[1]]
# Plot the tree
plot(t1, uniform=T, branch=0, margin=0.1, main = 'classification tree')
text(t1, splits=T, all = T, fancy = T)

# Compute the accuracy of AdaBoost model on the training and test data sets
y_test_pred_AdaBoost1 <- predict(M_AdaBoost1, D_test)
accuracy_test_AdaBoost1 <- sum(y_test==y_test_pred_AdaBoost1$class) / n_test
msg <- paste0('accuracy_test_AdaBoost1 = ', accuracy_test_AdaBoost1)
print(msg)

y_train_pred_AdaBoost1 <- predict(M_AdaBoost1, D_train)
accuracy_train_AdaBoost1 <- sum(y_train==y_train_pred_AdaBoost1$class) / n_train
msg <- paste0('accuracy_train_AdaBoost1 = ', accuracy_train_AdaBoost1)
print(msg)
