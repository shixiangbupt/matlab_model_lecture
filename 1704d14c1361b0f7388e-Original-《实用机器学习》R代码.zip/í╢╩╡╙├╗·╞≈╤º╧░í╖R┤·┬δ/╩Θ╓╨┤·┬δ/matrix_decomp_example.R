# matrix_decomp_example.R
# In this script, we demonstrate some basic matrix decompositions in R

# Remove all objects in the workspace
rm(list=ls())

# Step 1. Generate a random matrix
set.seed(1)
A = matrix(rnorm(16), 4, 4)
B = matrix(rnorm(12), 4, 3)

# Step 2. Demonstrate the use of diag
A_diag = diag(A)
B_diag = diag(B)
v = c(1, 2, 5, 3)
V = diag(v)
I_matrix = diag(4)
D_matrix = diag(5,4)
# Change the diagnoal of A directly
diag(A) <- diag(A) * 2
# Change the diagonal of B directly
diag(B) <- diag(B) + 5


# Step 3. Eigen-decomposition
E_A = eigen(A)
E_A$values
E_A$vectors
# Verify the decomposition
Delta_A = E_A$vectors %*% diag(E_A$values) %*% solve(E_A$vectors) - A

# If we only require eigenvalues
E_A_only = eigen(A, only.values = T)
E_A_only$values
# E_A_only$vectors is NULL
E_A_only$vectors

# Compute eigen-decomposition for sysmetric matrix
AA = A + t(A)
E_AA = eigen(AA, symmetric=T)
E_AA$values
E_AA$vectors
# Verify the decomposition
Delta_AA = E_AA$vectors %*% diag(E_AA$values) %*% t(E_AA$vectors) - AA

# Step 4. SVD
S_B = svd(B)
S_B$u
S_B$v
S_B$d
# Verify the decomposition
Delta_B = S_B$u %*% diag(S_B$d) %*% t(S_B$v) - B

