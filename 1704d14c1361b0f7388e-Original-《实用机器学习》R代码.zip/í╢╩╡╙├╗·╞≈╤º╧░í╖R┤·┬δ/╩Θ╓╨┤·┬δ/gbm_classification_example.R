# gbm_classification_example.R
# In this script, we demonstrate how to use gbm to build a gradient boosting tree
# for classification.

# Remove all objects in the workspace
rm(list=ls())


# Step 0. Check required package is installed or not. If not, install first.
# 1. gbm
gbm.installed <- 'gbm' %in% rownames(installed.packages())
if (gbm.installed) {
  print("the gbm package is already installed, let's load it...")
}else {
  print("let's install the gbm package first...")
  install.packages('gbm', dependencies=T)
}
library(gbm)
# 2. mlbench
mlbench.installed <- 'mlbench' %in% rownames(installed.packages())
if (mlbench.installed) {
  print("the mlbench package is already installed, let's load it...")
}else {
  print("let's install the mlbench package first...")
  install.packages('mlbench', dependencies=T)
}
library(mlbench)

# Step 1. Load the data
data(PimaIndiansDiabetes2,package='mlbench')
D <- PimaIndiansDiabetes2
y <- D[[ncol(D)]]
y <- as.integer(y) - 1
D[[ncol(D)]] <- NULL
D$classLabel <- y


# Show the type for each col
for(i in 1:ncol(D)) {
  msg <- paste('col ', i, ' and its type is ', class(D[,i]))
  print(msg)
}

# Step 2. Split the data into training and test sets
# Randomly split the whole data set into a training and a test data set
# After spliting, we have the training set: (X_train, y_train)
# and the test data set: (X_test, y_test)
train_ratio <- 0.7
n_total <- nrow(D)
n_train <- round(train_ratio * n_total)
n_test <- n_total - n_train
set.seed(42)
list_train <- sample(n_total, n_train)
D_train <- D[list_train,]
D_test <- D[-list_train,]

y_train <- D_train$classLabel
y_test <- D_test$classLabel


# Step 3. Train several gbm models
# Train a simple gbm model
M_gbm1 <- gbm(classLabel~.,
              data = D_train, 
              distribution = 'bernoulli', 
              shrinkage = 0.01, 
              interaction.depth = 1,
              n.trees = 300, 
              verbose = T)
print('the summary of M_gbm1 is')
print(M_gbm1)

# Expand the gbm model by adding more trees
M_gbm1.1 <- gbm.more(M_gbm1, n.new.trees = 100)
print('the summary of M_gbm1.1 is')
print(M_gbm1.1)


# Train a gbm model using cross-validation
set.seed(1)
M_gbm2 <- gbm(classLabel~.,
              data = D_train, 
              distribution='bernoulli', 
              shrinkage = 0.01,
              n.trees=3000,
              cv.folds = 5,
              verbose=F)
print('the summary of M_gbm2 is')
print(M_gbm2)

# We use gbm.perf to get the estimate of the optimal number of trees using cross-validation
best.iter2 <- gbm.perf(M_gbm2,method = 'cv')
msg <- paste0('the best n.tree is ', best.iter2)
print(msg)
# Show the variable importance using the first best.iter2 trees
varImp2 <- summary(M_gbm2, best.iter2, main = 'variable importance of M_gbm2')
# Show the marginal effect of the selected variables by "integrating" out the other variables
# Here we select the 3rd variable.
plot.gbm(M_gbm2, 3, best.iter2)

# compactly print the first and last trees for curiosity
print('the structure of the 1st tree')
print(pretty.gbm.tree(M_gbm2,1))
print('the structure of the last tree')
print(pretty.gbm.tree(M_gbm2, M_gbm2$n.trees))

# predict the new data using the "best" number of trees
y_test_pred_gbm2 <- predict(M_gbm2, D_test, best.iter2, type = 'response')
print('we are going to print the first few predictions of y_test_pred_gbm2')
print(head(y_test_pred_gbm2))
y_test_pred_gbm2_raw <- predict(M_gbm2, D_test, best.iter2, type = 'link')
print('we are going to print the first few predictions of y_test_pred_gbm2_raw')
print(head(y_test_pred_gbm2_raw))



# Train a more complicated model
M_gbm3 <- gbm(classLabel~.,
              data = D_train, 
              distribution='bernoulli', 
              shrinkage = 0.005, 
              bag.fraction = 0.4, 
              cv.folds = 5,
              interaction.depth = 2,
              n.cores = 4,
              n.trees=3000, 
              verbose=F)
print('the summary of M_gbm3 is')
print(M_gbm3)

# Step 4. Use gbm to do multi-class classification
data(iris)
M_iris <- gbm(Species ~ ., 
              distribution="multinomial", 
              data=iris,
              n.trees=2000, 
              shrinkage=0.01, 
              cv.folds=5,
              verbose=F, 
              n.cores=1)
print('the summary of M_iris is')
print(M_iris)
print('the variable importance of M_iris')
summary(M_iris, main = 'variable importance of M_iris')

