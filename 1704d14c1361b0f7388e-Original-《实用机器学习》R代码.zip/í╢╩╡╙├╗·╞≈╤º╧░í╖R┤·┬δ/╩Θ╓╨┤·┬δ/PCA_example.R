# PCA_example.R
# In this script, we show how to use the function prcomp to apply PCA in R.

# Remove all objects in the workspace
rm(list=ls())

#=== The following is copied from an online page
# Load data
data(iris)
D = iris
# show the basic information of  the data 
str(D)

# log transform 
D_log <- log(D[, 1:4])

# apply PCA
M_pca <- prcomp(D_log, center = TRUE, scale. = TRUE) 

# print method
print(M_pca)
# members of M_pca
M_pca$sdev
M_pca$rotation

# plot method
plot(M_pca, type = "l")

# summary method
summary(M_pca)

#Predict PCs
y_test <- predict(M_pca, newdata= D_log[1:10,])
