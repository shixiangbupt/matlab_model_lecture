# logistic_regression_example.R
# In this script, we demonstrate how train logistic regression using the glmnet package.

# In this version, we use the Sonar data set

# Remove all objects in the workspace
rm(list=ls())

# Step 0. Check required packages are installed or not. If not, install them.
glmnet.installed <- 'glmnet' %in% rownames(installed.packages())
if (glmnet.installed) {
  print("the glmnet package is already installed, let's load it...")
}else {
  print("let's install the glmnet package first...")
  install.packages('glmnet', dependencies=T)
}
library('glmnet')
# We use pROC package to display and analyze ROC curves
pROC.installed <- 'pROC' %in% rownames(installed.packages())
if (pROC.installed) {
  print("the pROC package is already installed, let's load it...")
  
}else {
  print("let's install the pROC package first...")
  install.packages('pROC', dependencies=T)
}
library('pROC')
# We use the Sonar dataset included in mlbench package
mlbench.installed <- 'mlbench' %in% rownames(installed.packages())
if (mlbench.installed) {
  print("the mlbench package is already installed, let's load it...")
}else {
  print("let's install the mlbench package first...")
  install.packages('mlbench', dependencies=T)
}
library(mlbench)

# Step 1. Load the Sonar data from mlbench package
data(Sonar)
D <- Sonar

# show the type for each column
str(D)

# Check the first 10 rows and save them in LaTeX format
D_h10 <- head(D, 10)
print('the first 10 rows are:')
print(D_h10)
D_t10 <- tail(D, 10)
print('the last 10 rows are:')
print(D_t10)


# Randomly split the whole data set into a training and a test data set
# After spliting, we have the training set: (X_train, y_train)
# and the test data set: (X_test, y_test)
# Set seed for reproducibility
set.seed(13)
train_ratio <- 0.8
n_total <- nrow(D)
n_train <- round(train_ratio * n_total)
n_test <- n_total - n_train
list_train <- sample(n_total, n_train)
y_train <- D[list_train, 'Class']
y_test <- D[-list_train, 'Class']
X_train <- D[list_train,]
X_train$Class <- NULL
X_train <- as.matrix(X_train)
X_test <- D[-list_train,]
X_test$Class <- NULL
X_test <- as.matrix(X_test)


# Model 1: train a simple logistic regression model without regularization
family <- 'binomial'
lambda <- 0
alpha <- 0
# train a logistic regression model
M1 <- glmnet(X_train, y_train, family = family, lambda = lambda, alpha = alpha)
# make the prediction on the test data set and compute the performance
y_test_predict1 <- predict(M1, X_test, type='class')
y_test_prob1 <- predict(M1, X_test, type='response')
y_test_raw1 <- predict(M1, X_test, type='link')

# Compute accuracy and AUC
y_test_numeric <- ifelse(y_test==levels(y_test)[2], 1, 0)
accuracy1 <- sum(y_test==y_test_predict1)/n_test
auc1 <- auc(y_test, as.numeric(y_test_prob1))
msg <- paste('accuracy = ', accuracy1)
print(msg)
msg <- paste('auc = ', auc1)
print(msg)

# Model 2: train a logistic regression with L1-norm regularization
family <- 'binomial'
lambda <- 0.05
alpha <- 1
M2 <- glmnet(X_train, y_train, family = family, lambda = lambda, alpha = alpha)
# make the prediction on the test data set and compute the performance
y_test_predict2 <- predict(M2, X_test, type='class')
y_test_prob2 <- predict(M2, X_test, type='response')
accuracy2 <- sum(y_test==y_test_predict2)/n_test
auc2 <- auc(y_test, as.numeric(y_test_prob2))
msg <- paste('accuracy = ', accuracy2)
print(msg)
msg <- paste('auc = ', auc2)
print(msg)
print('the coefficients of w are')
print(M2$beta)


# Model 3: train a logistic regression with L2-norm regularization
family <- 'binomial'
lambda <- 0.05
alpha <- 0
M3 <- glmnet(X_train, y_train, family = family, lambda = lambda, alpha = alpha)
# make the prediction on the test data set and compute the performance
y_test_predict3 <- predict(M3, X_test, type='class')
y_test_prob3 <- predict(M3, X_test, type='response')
accuracy3 <- sum(y_test==y_test_predict3)/n_test
auc3 <- auc(y_test, as.numeric(y_test_prob3))
msg <- paste('accuracy = ', accuracy3)
print(msg)
msg <- paste('auc = ', auc3)
print(msg)

# Model 4: train a logistic regression with both L1 and L2-norm regularization
family <- 'binomial'
lambda <- 0.05
alpha <- 0.3
M4 <- glmnet(X_train, y_train, family = family, lambda = lambda, alpha = alpha)
# make the prediction on the test data set and compute the performance
y_test_predict4 <- predict(M4, X_test, type='class')
y_test_prob4 <- predict(M4, X_test, type='response')
accuracy4 <- sum(y_test==y_test_predict4)/n_test
auc4 <- auc(y_test, as.numeric(y_test_prob4))
msg <- paste('accuracy = ', accuracy4)
print(msg)
msg <- paste('auc = ', auc4)
print(msg)

# Model 5. train a logistic regression with a sequence of lambda. Note that alpha
# is fixed. Here we set alpha to 0 so only L2-norm regularization is considered.
lambda_list <- seq(0.05, 0, by=-0.005)
alpha <- 0
lambda_num <- length(lambda_list)
accuracy_train_list <- rep(0, lambda_num)
accuracy_test_list <- rep(0, lambda_num)
family <- 'binomial'
M5_list <- glmnet(X_train, y_train, family = family, lambda=lambda_list, alpha=alpha)
y_test_predict_matrix <- predict(M5_list, X_test, type='class')
y_train_predict_matrix <- predict(M5_list, X_train, type='class')
# We compute accuracy for these models on training and test data sets
for (i in 1:lambda_num) {
  accuracy_train_list[i] <- sum(y_train==y_train_predict_matrix[,i])/n_train
  accuracy_test_list[i] <- sum(y_test==y_test_predict_matrix[,i])/n_test
}

# Model 6: train a logistic regression model without providing lambda and alpha
# glmnet will consider a sequence of lambda values.
# Note that only L1-norm is considered
M6 <- glmnet(X_train, y_train, family = family, alpha=1)
plot(M6)
print(M6)
coef6 <- coef(M6, s=0.01)
y_test_predict6 <- predict(M6, X_test, s=c(0.005, 0.01), type='class')

# accuracy6 <- sum(y_test==y_test_predict6)/n_test
# msg <- paste('accuracy = ', accuracy6)
# print(msg)
# we can see that y_test_predict5 is a matrix consists of 2 columns


# Model 7. Use CV to build a logistic regression model
# The list of lambda valuies are also generated by glmnet itself
M_cv = cv.glmnet(X_train, y_train, family = family, type.measure = 'class', nfolds=5)
#M_cv = cv.glmnet(X_train, y_train, family = family, type.measure = 'auc', nfolds=5)
plot(M_cv)
# the optimal lambda
M_cv$lambda.min
# get the coefficient corresponding the optimal lambda
coef7 <- coef(M_cv, s = "lambda.min")
# make prediction using the optimal lambda value
y_test_predict7 <- predict(M_cv, X_test, s="lambda.min", type='class')
accuracy7 <- sum(y_test==y_test_predict7)/n_test
msg <- paste('accuracy = ', accuracy7)
print(msg)