# R_data_preprocess.R
# In this script we demonstrate how to preprocess the data

# Remove all objects in the workspace
rm(list=ls())

data(iris)
D <- iris[,1:4]
D1 <- D[1:100,]
D2 <- D[101:150,]
D1_normalized <- scale(D1, center = T, scale = T)
D2_normalized <- scale(D2, 
                       center = attr(D1_normalized, 'scaled:center'),
                       scale = attr(D1_normalized, 'scaled:scale'))

attr(D1_normalized, 'scaled:center')
attr(D1_normalized, 'scaled:scale')

apply(D1_normalized, 2, sum)
apply(D1_normalized, 2, sd)