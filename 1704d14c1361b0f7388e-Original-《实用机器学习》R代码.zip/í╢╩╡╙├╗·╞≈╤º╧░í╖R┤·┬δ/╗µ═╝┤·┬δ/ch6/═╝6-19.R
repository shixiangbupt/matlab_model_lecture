# In this script, we plot different loss functions, 
# and generate the legend for each line individually.
# 1. 0-1 loss
# 2. hinge loss
# 3. cross-entropy loss
# 4. exponential loss
# 5. sum-of-squares loss
rm(list=ls())

yf = seq(-3, 2, by=0.01)
x_range = range(yf)
y_range = c(0, 1-min(x_range))
plot(x_range, y_range, type="n", xlab="yf", ylab="Loss") 
lwd = 2


# Draw hinge loss
yf1 = yf[yf<1]
h1 = 1 - yf1
yf2 = yf[yf>=1]
h2 = rep(0, length(yf2))
h = c(h1, h2)
lines(yf, h, lwd=lwd, type='l', col='blue')

# Draw 0-1 loss
yf3 = yf[yf<=0]
l3 = rep(1, length(yf3))
yf4 = yf[yf>=0]
l4 = rep(0, length(yf4))
yf_draw = c(yf3, yf4)
l = c(l3, l4)
lines(yf_draw, l, lwd=lwd, type='l', col='black')

# Draw the sum-of-squares loss
s = (1-yf)^2
lines(yf, s, lwd=lwd, type='l', col='red')

# Draw the exponential loss
e = exp(-yf)
lines(yf, e, lwd=lwd, type='l', col='yellow')

# Draw the cross-entropy loss 
ce = log(1 + exp(-yf))
lines(yf, ce, lwd=lwd, col='green')

# generate legend
#legend_char_list <- c('0-1', 'hinge', 'sum-of-squares', 'exponential', 'cross-entropy')
#col_list = c('black', 'blue', 'red', 'yellow', 'green')
#legend('topright', legend_char_list, cex=1.25, col=col_list, lty=c(1,1), lwd=lwd)

legend(locator(1), '0-1', cex=1, box.col='white')
legend(locator(1), 'cross-entropy', cex=1, box.col='white')
legend(locator(1), 'hinge', cex=1, box.col='white')
legend(locator(1), 'expenential', cex=1, box.col='white')
legend(locator(1), 'sum-of-squares', cex=1, box.col='white')


# legend(locator(1), legend_char_list, cex=0.8, col=c('red', 'black'), lty=c(1,1))
# 
# legend_char_list = c('High Bias', 'Low Variance')
# legend(locator(1), legend_char_list, cex=0.8, box.col='white')
# 
# legend_char_list = c('Low Bias', 'High Variance')
# legend(locator(1), legend_char_list, cex=0.8, box.col='white')

