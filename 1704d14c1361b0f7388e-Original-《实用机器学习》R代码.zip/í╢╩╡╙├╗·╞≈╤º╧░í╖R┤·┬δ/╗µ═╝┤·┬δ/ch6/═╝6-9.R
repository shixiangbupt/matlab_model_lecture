# This plot draws the signmoid function

x = seq(-10, 10, by=0.1)
y = 1 / (1 + exp(-x))

plot(x, y, ylim=c(0,1), type='l', col='red')
lines(c(0,0), c(-0.5,1.5), col='black', lty='dashed')
lines(c(min(x)-1, max(x)+1), c(0.5,0.5), lty='dashed')

