# In this script, we plot different loss functions, 
# and generate the legend for each line individually.
# 1. 0-1 loss
# 2. hinge loss

rm(list=ls())

yf = seq(-4, 4, by=0.01)
x_range = range(yf)
y_range = c(0, 1-min(x_range))
plot(x_range, y_range, type="n", xlab="yf", ylab="Loss") 
lwd = 2


# Draw hinge loss
yf1 = yf[yf<1]
h1 = 1 - yf1
yf2 = yf[yf>=1]
h2 = rep(0, length(yf2))
h = c(h1, h2)
lines(yf, h, lwd=lwd, type='l', col='blue')

# Draw 0-1 loss
yf3 = yf[yf<=0]
l3 = rep(1, length(yf3))
yf4 = yf[yf>=0]
l4 = rep(0, length(yf4))
yf_draw = c(yf3, yf4)
l = c(l3, l4)
lines(yf_draw, l, lwd=lwd, type='l', col='black')

# generate legend
legend_char_list <- c('hinge', '0-1')
col_list = c('blue', 'black')
legend('topright', legend_char_list, cex=1.25, col=col_list, lty=c(1,1), lwd=lwd)





