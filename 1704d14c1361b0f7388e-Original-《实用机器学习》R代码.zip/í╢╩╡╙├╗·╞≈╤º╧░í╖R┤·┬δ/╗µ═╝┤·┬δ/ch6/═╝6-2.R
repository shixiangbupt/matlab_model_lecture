# In this script, we draw the plot of entropy and Gini index

# y-axis: entropy
# x-axis: P_positive
rm(list=ls())


pp = seq(0, to=1, by=0.01)

y = -pp*log2(pp) - (1-pp) * log2(1-pp)
y[is.na(y)] <-0
y_gini = 1 - pp^2 - (1-pp)^2

xlab <- 'P+'
ylab <- 'Entropy'
x_range=range(pp)
y_range = range(y)
y_range[2] <- y_range[2] + 0.1
plot(x_range, y_range, type='n', xlab=xlab, ylab=ylab, main='Entropy and Gini Index')
lty <- 'solid'
lwd = 2
lines(pp, y, lwd=lwd, col='red', lty=lty)
lines(pp, y_gini, lwd=lwd, col='blue', lty='dashed')
legend_char_list <- c('Entropy', 'Gini Index')
legend('topright', legend_char_list, cex=1, col=c('red', 'blue'), lty=c('solid', 'dashed'))

# legend_char <- 'Entropy'
# legend('topleft', legend_char)



