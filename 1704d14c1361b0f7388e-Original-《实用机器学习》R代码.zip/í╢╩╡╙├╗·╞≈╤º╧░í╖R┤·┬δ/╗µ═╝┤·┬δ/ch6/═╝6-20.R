# In this script, we plot the contour of different Lp norms

#======================
# Please specify p here
p = 10
#======================

z = 1
x = seq(-1, 1, by=0.01)
xrange = range(x)
yrange = xrange

#plot(xrange, yrange, type='n', xlab="x", ylab="y") 
require(MASS)
lwd = 2
col = 'red'


eqscplot(xrange, yrange, ratio=1, type='n', xlab="x", ylab="y") 
lines(c(-10,10), rep(0, 2), lwd=lwd)
lines(rep(0, 2), c(-10, 10), lwd=lwd)

xp = x[x>=0]
yp = (z-xp^p)
yp = yp^(1/p)

# 1st phase
lines(xp, yp, lwd=lwd, col=col)
# 2nd phase
lines(xp, -yp, lwd=lwd, col=col)
# 3rd phase
lines(-xp, -yp, lwd=lwd, col=col)
# 4th phase
lines(-xp, yp, lwd=lwd, col=col)

# Create the legend
legend_str <- paste0("p=", p)
legend('topright', legend_str, cex=1.5)

