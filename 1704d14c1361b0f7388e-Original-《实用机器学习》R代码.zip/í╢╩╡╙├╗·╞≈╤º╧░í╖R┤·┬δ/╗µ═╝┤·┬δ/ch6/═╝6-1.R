library(rpart)
data(iris) # this command is not necessary.
head(iris)

names(iris)

nrow(iris)

# Let iris.rp = tree object fitting Species vs. all other
M_iris = rpart(Species~., iris, method="class")
# Plot tree diagram with uniform spacing,
# diagonal branches, a 10% margin, and a title
plot(M_iris, uniform=T, branch=0, margin=0.1, main = 'Decision tree on iris data')
text(M_iris, splits=T, all = T, fancy = T)

# plot(M_iris, uniform=T, branch=0, margin=0.1, main="
#      Classification Tree\nIris Species by Petal and Sepal
#      Length")
# Add labels to tree with final counts,
# fancy shapes, and blue text color
#text(M_iris,  use.n=T, fancy=T, col="blue")
#text(M_iris, use.n=TRUE, all=TRUE, cex=.8)
#text(M_iris, splits=T, all = T, fancy = T)

table(iris$Species)
# 
# print(iris.rp, digit=3)


# # Split the data into training and test and then
# # compute the prediction on both the training and test sets
# 
# ris.rp3=predict(iris.rp2, iris.test[,-5], type="class")
# table(iris.test[,5],iris.rp3)

# plot(fit, uniform=TRUE, 
#      main="Classification Tree for Kyphosis")
# text(fit, use.n=TRUE, all=TRUE, cex=.8)