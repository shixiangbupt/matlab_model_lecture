# In this plot, we plot the absolute value of wj

x_list = seq(-4, 4, by=0.01)
y_list = abs(x_list)



# Draw model 1
lty = 'dashed'
col = 'blue'
lwd = 2
plot(x_list,y_list,xlab='wj', ylab='|wj|',  lwd=lwd, col=col, type='l')
abline(c(0,0))
lines(c(0,0), c(-1,5))