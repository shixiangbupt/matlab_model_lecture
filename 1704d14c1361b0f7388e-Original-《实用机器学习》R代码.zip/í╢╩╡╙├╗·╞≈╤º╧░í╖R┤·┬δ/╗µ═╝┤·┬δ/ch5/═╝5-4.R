# In this script, we plot the change of magnitudes of coefficients when the regularization parameter varies.
rm(list=ls())
glmnet.installed <- 'glmnet' %in% rownames(installed.packages())
if (glmnet.installed) {
  print("the glmnet package is already installed, let's load it...")
  library('glmnet')
}else {
  print("let's install the glmnet package first...")
  install.packages('glmnet', dependencies=T)
  library('glmnet')
}

# This script plots the figure used to demonstrate the least squares method
rm(list=ls())
d_in <- 'Data'
f_in = 'housing.csv'
target_idx <- -1
f_in_full <- file.path(d_in, f_in)
D <- read.csv(f_in_full)

#====================== lasso part ==================
family <- 'gaussian'
alpha <- 1
# perform lasso
lambda_list <- seq(0, 2, by=0.05)
lambda_list <- exp(lambda_list) - 1
lambda_num <- length(lambda_list)
#nlambda <- lambda_num
var_num <- ncol(D) - 1
W_matrix <- matrix(var_num+1, lambda_num)
X <- D[,1:var_num]
y <- D[[ncol(D)]]
Ms <- glmnet(as.matrix(X), y, family = family, lambda=lambda_list, alpha=alpha)
W_matrix <- Ms$beta
x_range <- range(log(lambda_list+1))
# x_range[1] <- x_range[1] - 1
y_range <- range(W_matrix)
par(mfrow=c(1,1))
plot(x_range, y_range, type="n", xlab="log(lambda+1)",
     ylab="Coefficients" ) 
colors <- rainbow(var_num) 
linetype <- c(1:var_num) 
#plotchar <- seq(18,18+var_num-1,1)
plotchar <- 1:var_num
for(i in 1:var_num) {  
  lines(log(lambda_list+1), rev(W_matrix[i,]), type="b", lwd=1,
        lty=linetype[i], col=colors[i], pch=plotchar[i])
  lines(log(lambda_list+1), rev(W_matrix[i,]), type="l", lwd=1,
        lty=linetype[i], col=colors[i], pch=plotchar[i])
}
title("W as lambda increases")

legend(locator(1), paste('w', 1:var_num, sep=''), cex=0.8, col=colors, 
       pch=plotchar, lty=linetype, title="Coefficient")
abline(c(0,0), col='red', lwd=2)




