# This script plots the figure used to demonstrate the least squares method
rm(list=ls())
d_in <- 'Data'
f_in = 'housing.csv'
target_idx <- -1


f_in_full <- file.path(d_in, f_in)


D <- read.csv(f_in_full)


scatterplot3d.installed <- 'scatterplot3d' %in% rownames(installed.packages())
if (scatterplot3d.installed) {
  print("the scatterplot3d package is already installed, let's load it...")
  library('scatterplot3d')
}else {
  print("let's install the scatterplot3d package first...")
  install.packages('scatterplot3d', dependencies=T)
  library('scatterplot3d')
}

crim <- D$crim
rm <- D$rm
medv <- D$medv
age <- D$age
# age <- D$tax
# s3d <- scatterplot3d(age, crim, medv, pch=16, highlight.3d=T, type='p', main="��С���˷�",
#                      xlab='x1', ylab='x2', zlab='y')
s3d <- scatterplot3d(age, crim, medv, pch=16, highlight.3d=T, type='p',
                     xlab='x1', ylab='x2', zlab='y')
fit <- lm(medv ~ crim + age)
s3d$plane3d(fit, lty.box='solid')
# 
# attach(mtcars) 
# s3d <-scatterplot3d(wt,disp,mpg, pch=16, highlight.3d=TRUE,
#                     type="p", main="3D Scatterplot")
# fit <- lm(mpg ~ wt+disp) 
# s3d$plane3d(fit, lty.box='solid')
# 
# 
# 
# # 3D Scatterplot with Coloring and Vertical Drop Lines
# library(scatterplot3d) 
# attach(mtcars) 
# scatterplot3d(wt,disp,mpg, pch=24, highlight.3d=TRUE,
#               type="h", main="3D Scatterplot")
# s3d <-scatterplot3d(wt,disp,mpg, pch=16, highlight.3d=TRUE,
#                     type="p", main="3D Scatterplot")
# fit <- lm(mpg ~ wt+disp) 
# s3d$plane3d(fit, lty.box='solid')