# In this script, we plot the change of magnitudes of coefficients when the regularization parameter varies.
rm(list=ls())
library('glmnet')

# This script plots the figure used to demonstrate the least squares method
rm(list=ls())
d_in <- 'Data'
f_in = 'housing.csv'
target_idx <- -1
f_in_full <- file.path(d_in, f_in)
D <- read.csv(f_in_full)


# # perform ridge regression
f_lasso = 'Figures/lasso1'
family <- 'gaussian'
alpha <- 0
#lambda_list <- seq(0, 8, by=0.2)
lambda_list <- seq(8, 0, by=-0.2)
lambda_list <- exp(lambda_list) - 1
#nlambda <- lambda_num
var_num <- ncol(D) - 1
X <- D[,1:var_num]
y <- D[[ncol(D)]]
Ms <- glmnet(as.matrix(X), y, family = family, lambda=lambda_list, alpha=alpha)

#============= Revised version on 04/16/2016 ======
# We can use the plot (in fact plot.glmnet) function to plot w vs lambda directly
plot(Ms, xvar='lambda', label=T)
#============= Revised version on 04/16/2016 ======

W_matrix <- Ms$beta
x_range <- range(log(lambda_list+1))
# x_range[1] <- x_range[1] - 1
y_range <- range(W_matrix)
par(mfrow=c(1,1))
plot(x_range, y_range, type="n", xlab="log(lambda+1)",
     ylab="Coefficients" )
colors <- rainbow(var_num)
linetype <- c(1:var_num)
#plotchar <- seq(18,18+var_num-1,1)
plotchar <- 1:var_num
lambda_list <- Ms$lambda
for(i in 1:var_num) {
  lines(log(lambda_list+1), W_matrix[i,], type="b", lwd=1,
        lty=linetype[i], col=colors[i], pch=plotchar[i])
  lines(log(lambda_list+1), W_matrix[i,], type="l", lwd=1,
        lty=linetype[i], col=colors[i], pch=plotchar[i])
}
title("W as lambda increases")

legend('bottomright', paste('w', 1:var_num, sep=''), cex=0.8, col=colors,
       pch=plotchar, lty=linetype, title="Coefficient")
# legend(locator(1), paste('w', 1:var_num, sep=''), cex=0.8, col=colors,
#        pch=plotchar, lty=linetype, title="Coefficient")
abline(c(0,0), col='red', lwd=2)

