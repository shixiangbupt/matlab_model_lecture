
xf = seq(0, 7.5, by=0.01)
x_range = range(xf)
y_range = c(0, 6)
#plot(x_range, y_range, type="n", xlab="", ylab="")
plot(x_range, y_range, type="n", xlab="", ylab="", xaxt='n', yaxt='n')
symbol_list = c('@', '+', '%', '#', 'A', 'a', 'm', '?:', '*:')
x_min = 1
x_max = 7
y_min = 1
y_max = 5
x_num = x_max - x_min + 1
y_num = y_max - y_min + 1
n_total = x_num * y_num
for (i in 1:n_total) {
  p_x = i%%x_num
  if (p_x==0) {
    p_x = x_max
  }
  p_y = y_max - ceiling(i/x_num) + 1
  if (i<=26) {
    number2show = i - 1
    points(p_x, p_y, pch=number2show)
    text(p_x-0.2, p_y, as.character(number2show))
  }else {
    points(p_x, p_y, pch=symbol_list[i-26])
  }
}
