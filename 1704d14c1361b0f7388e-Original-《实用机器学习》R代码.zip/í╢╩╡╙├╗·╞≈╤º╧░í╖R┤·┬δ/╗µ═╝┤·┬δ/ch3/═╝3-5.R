# In this script, we generate a set of data points which can be projected onto the 1-dimensional space

n = 1000
x1 = rnorm(n)
epsilon = rnorm(n) * 0.2
x2 = 1 + 0.4 * x1 + epsilon
plot(x1, x2, pch=19)
# plot a line
M <- lm(x2~x1)
abline(lm(x2~x1), col='red', lwd=2)

# # apply pca and plot the 1st component
# M <- princomp(cbind(x1,x2))
# summary(M)
# plot(M, type='lines')



x = seq(-4, 4, by=0.01)
y = 1 + 0.4 * x
lines(x, y, col='red', lwd=3)

