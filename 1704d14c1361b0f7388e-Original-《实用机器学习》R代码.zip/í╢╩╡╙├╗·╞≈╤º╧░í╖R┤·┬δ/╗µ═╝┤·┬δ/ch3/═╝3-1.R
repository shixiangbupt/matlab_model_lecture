# In this script, we plot the distribution of N(0,1)


normal_density <- function(x, mu=0, sigma=1) {
  y = 1/sqrt(2*pi)/sigma * exp(-(x-mu)^2/2/sigma^2)
}

x = seq(-5, 5, by=0.01)
y = normal_density(x)
plot(x, y, type='l', main='the distribution of N(0,1)', ylab='p(x)')
