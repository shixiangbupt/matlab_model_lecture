# In this script, we give some sknew demos

x = seq(0, 1, by=0.001)

a = 2
b = 4
y1 = dbeta(x, a, b)
plot(x, y1, type='l', lwd=2, ylab='p(x)')


y2 = dbeta(x, 4, 2)
plot(x, y2, type='l', lwd=2, ylab='p(x)')


# plot a normal distriubtion
x10 = seq(-6, 6, by=0.05)
y10 = dnorm(x10)
plot(x10, y10, type='l', lwd=2, ylab='p(x)')
